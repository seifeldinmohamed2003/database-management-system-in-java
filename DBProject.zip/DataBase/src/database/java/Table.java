package database.java;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.invoke.StringConcatFactory;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Table implements Serializable {
   

	private static final long serialVersionUID = 1L;
	
	Hashtable<Integer,String> pages;
	Hashtable<Integer,String> Indexes;
	String TableName;
	int numberOfPages;
	int numberOfIndexes;
	
	

	public Table(String strTableName) {
		this.TableName = strTableName;
		pages = new Hashtable<>();
		Indexes = new Hashtable<>();
		numberOfPages = 0;
		numberOfIndexes = 0;
		
	}
	
	public boolean hasIndex() {
		return ! Indexes.isEmpty();
	}
	
	
	public String hasIndexOn(String x, String y, String z) throws DBAppException {
		for(Integer key: Indexes.keySet()) {
			octTree<String> index = octTree.deserialize(Indexes.get(key));
			if(x.equals(index.colName1) || x.equals(index.colName2) || x.equals(index.colName3)) {
				if(y.equals(index.colName1) || y.equals(index.colName2) || y.equals(index.colName3)) {
					if(z.equals(index.colName1) || z.equals(index.colName2) || z.equals(index.colName3)) {
						octTree.serialize(index, Indexes.get(key));
						return Indexes.get(key);
					}
				}
			}
		}
		return null;
	}

	public static void serialize(Table table) throws DBAppException {
		try {
//			System.out.println("IO||||\t serialize:table:"+table.getTableName());
			
			FileOutputStream fileOut = new FileOutputStream("./src/main/resources/data/" + table.TableName + ".ser");
			
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(table);
			out.close();
			fileOut.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new DBAppException("IO Exception while writing to disk\t Table" + table.TableName);
		}
	}
	
	public static Table deserialize(String tableName) throws DBAppException {
		try {
//			System.out.println("IO||||\t deserialize:table:"+tableName);
			FileInputStream fileIn = new FileInputStream("./src/main/resources/data/"+tableName+".ser");
		
			
			ObjectInputStream in = new ObjectInputStream(fileIn);

			Table table = (Table) in.readObject();
			in.close();
			fileIn.close();

			return table;
		} catch (IOException e) {
			e.printStackTrace();
			throw new DBAppException(
					"IO Exception | Probably wrong table name (tried to operate on a table that does not exist !");
		} catch (ClassNotFoundException e) {
			throw new DBAppException("Class Not Found Exception");
		}
	}
	
	
	
	public String getPrimaryKey() {
		try {
			File metadataFile = new File("./src/main/resources/metadata.csv");
			FileReader fileReader = new FileReader(metadataFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			//String line = bufferedReader.readLine(); //skip first line (header line)
			String line = bufferedReader.readLine();
			while(line != null)
			{
				String[] data = line.split(",");
				if(data[0].equals(this.TableName) && (data[3]).equals("true") ) {
					return data[1];
				}
				line = bufferedReader.readLine();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public Hashtable<String, String> readTable() {
		try {
			File metadataFile = new File("./src/main/resources/metadata.csv");
			FileReader fileReader = new FileReader(metadataFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			//String line = bufferedReader.readLine(); //skip first line 
			Hashtable<String , String> ColNameType = new Hashtable<>();
			String line = bufferedReader.readLine();
			while(line != null)
			{
				String[] data = line.split(",");
				if(data[0].equals(this.TableName)) {
					ColNameType.put(data[1], data[2]);
				}
				line = bufferedReader.readLine();
			}
			
			return ColNameType;
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

	public String getPrimaryKeyType() {
		Hashtable<String, String> ColNameType = readTable();
		String primaryKey = getPrimaryKey();
		return ColNameType.get(primaryKey);
		
	}
	
	public Hashtable<String, String> getMin(){
		try {
			File metadataFile = new File("./src/main/resources/metadata.csv");
			FileReader fileReader = new FileReader(metadataFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			//String line = bufferedReader.readLine(); //skip first line 
			
			Hashtable<String , String> ColNameMin = new Hashtable<>();
			String line = bufferedReader.readLine();
			while(line != null)
			{
				String[] data = line.split(",");
				if(data[0].equals(this.TableName)) {
					ColNameMin.put(data[1], data[6]);
				}
				line = bufferedReader.readLine();

			}
	
			return ColNameMin;
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	public Hashtable<String, String> getMax(){
		try {
			File metadataFile = new File("./src/main/resources/metadata.csv");
			FileReader fileReader = new FileReader(metadataFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			//String line = bufferedReader.readLine(); //skip first line 
			
			Hashtable<String , String> ColNameMax = new Hashtable<>();
			String line = bufferedReader.readLine();
			while(line != null)
			{
				String[] data = line.split(",");
				
				if(data[0].equals(this.TableName)) {
					ColNameMax.put(data[1], data[7]);
				}
				line = bufferedReader.readLine();
			}
			
			return ColNameMax;
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
//this helper method gets the actual value of a string depending on its data type	
	public static Object parse(String value, String type) { 

		switch (type) {
		case "java.lang.Integer":
		{
			return Integer.parseInt(value);
		}
		case "java.lang.Double":
		{
			return Double.parseDouble(value);
		}
		case "java.util.Date":
		{
			return stringToDate(value, "yyyy-MM-dd");
		}
		case "java.lang.String":
		{
			return value;
		}
		default:
			return null;
		}
	}

	public static Date stringToDate(String dateString, String format) {
		// Create a SimpleDateFormat object with the desired date format
		DateFormat dateFormat = new SimpleDateFormat(format);

		// Parse the input string as a Date object
		Date date = null;
		try {
			date = dateFormat.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		// Return the result
		return date;
	}
	
	
//this helper method will be used upon insert, update, or delete any tuples it makes sure that the user entered valid data 
	private boolean check(Hashtable<String, Object> htblColNameValue) throws DBAppException {
		Hashtable<String, String> ColNameType = readTable();
		for(String key : htblColNameValue.keySet()) {
			if(!ColNameType.containsKey(key)) {
				throw new DBAppException("wrong column name");
			}
			String inputType = htblColNameValue.get(key).getClass().getName();
			String originalType = ColNameType.get(key);
			
			if(! inputType.equals(originalType)) {
				throw new DBAppException("values do not match types");
			}
		}
			
			
		return true;
	}

	
	public void update(String strClusteringKeyValue, Hashtable<String, Object> newValue) throws DBAppException {
		check(newValue); 
			
		if(strClusteringKeyValue == null) {
			throw new DBAppException("Primary Key field is null");
		}
		String pKtype = getPrimaryKeyType();
		Object pk = parse(strClusteringKeyValue, pKtype);
		if(hasIndex()) {
			String indexName = Indexes.get(0);
//			octTree<String> index = octTree.deserialize(indexName);
//			String colName1 = index.getColName1();
//			String colName2 = index.getColName2();
//			String colName3 = index.getColName3();
//			
//			if(newValue.containsKey(colName1) || newValue.containsKey(colName2)|| newValue.containsKey(colName3)) {
			for(Integer key: pages.keySet()) {
				Page page = Page.deserialize(pages.get(key));
				if(inRange(pk,page.minPK, page.maxPK)) {
					
					page.updateTupleWithIndex(pk, newValue , pKtype, indexName);
					Page.serialize(page);
					return;
				}
			}
//			}
//			octTree.serialize(index, indexName);
			
			
		}
		for(Integer key: pages.keySet()) {
			Page page = Page.deserialize(pages.get(key));
			if(inRange(pk,page.minPK, page.maxPK)) {
				page.updateTuple(pk, newValue , pKtype);
				Page.serialize(page);
				return;
			}
		}
		
		}
	//	throw new DBAppException("record does not exist");
	
	// following method could be used to delete one or more rows.
	// htblColNameValue holds the key and value. This will be used in search
	// to identify which rows/tuples to delete.
	// htblColNameValue enteries are ANDED together
	//assuming that the input hashtable contains multiple conditions for the tuple(s) to be deleted
	//EXAMPLE: delete age =18 & name = mohamed & name = ahmed
	//if these columns are not the primary keys for the tuples we have to search Linearlyy for the tuple(s) 
	//that satisfy all the conditions andded together
	
	
	public void delete(Hashtable<String, Object> htblColNameValue) throws DBAppException, IOException {
	    check(htblColNameValue);
	    boolean flag=false;
	    
	    
	   
	    Iterator<Integer> iter = pages.keySet().iterator();
	    while (iter.hasNext()) {
	        Integer key = iter.next();
	        Page page = Page.deserialize(pages.get(key));
	        String primaryKey = getPrimaryKey();
	        if(htblColNameValue.containsKey(primaryKey)) {
	        	String pKtype = getPrimaryKeyType();
				Object pk = htblColNameValue.get(primaryKey);
//				if(hasIndex()) {
//				String indexName = Indexes.get(0);
				if(inRange(pk,page.minPK , page.maxPK)) {
						page.delete2(htblColNameValue, pk, pKtype, Indexes);
						Page.serialize(page);
						return;
				    
					
//				page.delete2(htblColNameValue, pk, pKtype, indexName);
//				Page.serialize(page);
//				return;
				}
	        }
			
			
//	        if(hasIndex()) {
//				String indexName = Indexes.get(0);
//				index = octTree.deserialize(indexName);
//		    }
	      boolean s =page.delete(htblColNameValue, Indexes);
	     
	      
	       flag=flag||s;
	       
	        if (page.isEmpty()) {
	            FileInputStream fileIn = new FileInputStream("data/" + page.pageName + ".class");
	            fileIn.close();
	            File file = new File("data/" + page.pageName + ".class");
	            file.delete();
	            iter.remove(); // remove the current key from the iterator instead of using pages.remove(key)
	        } else {
	            Page.serialize(page);
	        }
	    }
	    if(!flag)
	    {
	    	throw new DBAppException("Tuples to be deleted does not exist");
	    }
	    
	}
	

	public boolean inRange(Object pk, Object min, Object max) { //just check if pk is >= min or <= max do not do binary search
		String pKtype = getPrimaryKeyType();
		switch (pKtype) {
		case "java.lang.Integer":{
			if (((Integer) pk).compareTo((Integer)min) >= 0 && ((Integer) pk).compareTo((Integer)max) <= 0) {
				
				return true;
			}
			break;
		}
		case "java.lang.Double":{
			if (((Double) pk).compareTo((Double)min) >= 0 && ((Double) pk).compareTo((Double)max) <= 0) {
				return true;
			}
			break;
		}
			
		case "java.util.Date":{
			if (((Date) pk).compareTo((Date)min) >= 0 && ((Date) pk).compareTo((Date)max) <= 0) {
				return true;
			}
			break;
		}
			
		case "java.lang.String":{
			if (((String) pk).compareTo((String)min) >= 0 && ((String) pk).compareTo((String)max) <= 0) {
				return true;
			}
			break;
		}
			
		default:
			break;
		}
		return false;
	}
	
	public void insertInIndex(Tuple tuple, String pageName,String indexName) throws DBAppException {
		octTree<String> index = octTree.deserialize(indexName);
		String colName1 = index.colName1;
		String colName2 = index.colName2;
		String colName3 = index.colName3;

		Object x = tuple.ColNameValue.get(colName1);
		Object y = tuple.ColNameValue.get(colName2);
		Object z = tuple.ColNameValue.get(colName3);

		index.insert(x, y, z, pageName+","+tuple.primaryKey);
		octTree.serialize(index, indexName);
	}
	
	public boolean insert(Hashtable<String, Object> htblColNameValue) throws DBAppException {
		check(htblColNameValue);
		
		String primaryKey = getPrimaryKey();
		String pKtype = getPrimaryKeyType();
		Object pk = htblColNameValue.get(primaryKey);
		if(pk==null) {
			throw new DBAppException("primary key does not exist");
		}
		Tuple newTuple = new Tuple(htblColNameValue, primaryKey ,pk ,pKtype);
		
		//case 0: empty table
		if(pages.isEmpty()) { //create a new page
			String firstPageName = TableName + "_"+ numberOfPages;
			Page firstPage = new Page(firstPageName,pk, pk);
			pages.put(numberOfPages, firstPageName);
			numberOfPages++;
			firstPage.insert(newTuple , 0);
			Page.serialize(firstPage);
			
			if(hasIndex()) {
				for(Integer key: Indexes.keySet()) {
					String indexName = Indexes.get(key);
					insertInIndex(newTuple, firstPageName, indexName);
					
				}
			}
			return true;
		}
		
		//find the right page
		int size = pages.size();
		int pageIndex = 0;
		for(int i = 0; i< size ; i++) {
			String pageName = pages.get(i);
			Page page = Page.deserialize(pageName);
			if(inRange(pk, page.minPK, page.maxPK)) {
				pageIndex = i;
				Page.serialize(page);
				break;
			}
			
			
			
			
			//special case
			String nextPageName = pages.get(i+1);
			if(nextPageName!=null) {
				Page nextPage = Page.deserialize(nextPageName);
				if(inRange(pk, page.maxPK, nextPage.minPK) && (!page.isFull())) {
					page.insert(newTuple, page.size());
					Page.serialize(nextPage);
					Page.serialize(page);
					if(hasIndex()) {
						for(Integer key: Indexes.keySet()) {
							String indexName = Indexes.get(key);
						insertInIndex(newTuple, pageName, indexName);
						}
					}
					return true;
				}
			}
			if((!page.isFull())&&(nextPageName==null)){
				pageIndex = i;
				Page.serialize(page);
				break;
			}
			if(pageIndex ==0  && (((Comparable)pk).compareTo((Comparable)page.minPK)<0)) {
				
				pageIndex = i;
				Page.serialize(page);
				break;
			}
			if(nextPageName == null) { // tuples exceeded range and next page not created 
				// create new page
				String newPageName = TableName +"_" + numberOfPages;
				Page newPage = new Page(newPageName, pk, pk);
				pages.put(numberOfPages, newPageName);
				numberOfPages++;
				newPage.insert(newTuple , 0);
				Page.serialize(newPage);
				Page.serialize(page);
				
				if(hasIndex()) {
					for(Integer key: Indexes.keySet()) {
						String indexName = Indexes.get(key);
					insertInIndex(newTuple, newPageName, indexName);
					}
				}
				
				return true;
				
				
			}
			
			Page.serialize(page);
		}
		
		String rightPageName = pages.get(pageIndex);
		Page rightPage = Page.deserialize(rightPageName); 
		int tupleIndex = rightPage.binarysearch(pk, pKtype);
		
		
		
		//case 1: page is not full
		if(!rightPage.isFull()) {
			//case 1-1: tuple place is empty 
			if(rightPage.getTuple(tupleIndex) == null) {
				rightPage.insert(newTuple, tupleIndex);
				Page.serialize(rightPage);
				if(hasIndex()) {
					for(Integer key: Indexes.keySet()) {
					String indexName = Indexes.get(key);
					insertInIndex(newTuple, rightPageName, indexName);
					}
				}
				return true;
			}
			//case 1-2: tuple place is not empty(must shift)
			if(rightPage.getTuple(tupleIndex) != null) {
				//if pk already exists
				if(rightPage.getTuple(tupleIndex).primaryKey.equals(pk)) {
					throw new DBAppException("primary key already exists");
				}
				rightPage.shift(tupleIndex);
				rightPage.insert(newTuple, tupleIndex);
				Page.serialize(rightPage);
				if(hasIndex()) {
					for(Integer key: Indexes.keySet()) {
						String indexName = Indexes.get(key);
						insertInIndex(newTuple, rightPageName, indexName);
					}
				}
				return true;
			}
		}
		
		//case 2: page is full
		if(rightPage.isFull()) {
			//case 2-1: tuple place is empty 
			if(rightPage.getTuple(tupleIndex) == null) {
				rightPage.insert(newTuple, tupleIndex);
				Page.serialize(rightPage);
				if(hasIndex()) {
					for(Integer key: Indexes.keySet()) {
						String indexName = Indexes.get(key);
						insertInIndex(newTuple, rightPageName, indexName);
					}
				}
				return true;
			}
			//case 2-2: tuple place is not empty(must shift)
			if(rightPage.getTuple(tupleIndex) != null) {
				//if pk already exists
				if(rightPage.getTuple(tupleIndex).primaryKey.equals(pk)) {
					throw new DBAppException("primary key already exists");
				}
				Tuple lastTuple = rightPage.getTuple(rightPage.size()-1);
				rightPage.shift(tupleIndex);
				rightPage.insert(newTuple, tupleIndex);
				Page.serialize(rightPage);
				if(hasIndex()) {
					for(Integer key: Indexes.keySet()) {
						String indexName = Indexes.get(key);
				
						insertInIndex(lastTuple, rightPageName, indexName);
					}
				}
				
				//insert the last tuple (resulting from shifting) in the right page
				for(int i = pageIndex + 1 ; i<=size ;i++) {
					String nextPageName = pages.get(i);
					
					//case 2-2-1: no next page 
					if(nextPageName == null) {
						String pageName = TableName +"_"+ numberOfPages;
						Page page = new Page(pageName ,lastTuple.primaryKey, lastTuple.primaryKey);
						pages.put(numberOfPages, pageName);
						numberOfPages++;
						page.insert(lastTuple, 0);
						Page.serialize(page);
						if(hasIndex()) {
							for(Integer key: Indexes.keySet()) {
								String indexName = Indexes.get(key);
								insertInIndex(lastTuple, pageName, indexName);
							
							}
							}
						return true;
					}
					Page nextPage = Page.deserialize(nextPageName);
					//case 2-2-2: next page is not full
					if(!nextPage.isFull()) {
						nextPage.shift(0);
						nextPage.insert(lastTuple, 0);
						Page.serialize(nextPage);
						if(hasIndex()) {
							for(Integer key: Indexes.keySet()) {
								String indexName = Indexes.get(key);
							insertInIndex(lastTuple, nextPageName, indexName);
							}
						}
						return true;
					}
					//case 2-2-3: next page is full
					if(nextPage.isFull()) {
						newTuple = lastTuple;
						lastTuple = nextPage.getTuple(nextPage.size()-1);
						nextPage.shift(0);
						nextPage.insert(newTuple, 0);
						Page.serialize(nextPage);
						if(hasIndex()) {
							for(Integer key: Indexes.keySet()) {
								String indexName = Indexes.get(key);
							insertInIndex(lastTuple, nextPageName, indexName);
							}
						}
					}
				}
			}
		}
		return false;
	}
	 public void display() throws DBAppException {
		 for(Integer key: pages.keySet()) {
				Page page = Page.deserialize(pages.get(key));
				System.out.println("page "+key +":" + page.toString());
				Page.serialize(page);
				}
				
	 }
	 
	 public ArrayList<Tuple> selectFromTable(SQLTerm s) throws DBAppException {
		 String colName = s._strColumnName;
		 String operator = s._strOperator;
		 Object value = s._objValue;
		 ArrayList<Tuple> result = new ArrayList<>();
		
		 switch(operator) {
		 case "=":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInTuple = t.ColNameValue.get(colName);
					 if(valueInTuple.equals(value)) {
						 result.add(t);
					 }
					 
				 }
				 Page.serialize(page);
			 }
			 
			 break;
		 case "!=":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInTuple = t.ColNameValue.get(colName);
					 if(!valueInTuple.equals(value)) {
						 result.add(t);
					 }
					 
				 }
				 Page.serialize(page);
			 }
			 break;
		 case ">":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInTuple = t.ColNameValue.get(colName);
					 String type = valueInTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInTuple).compareTo((Integer)value)>0) {
							 result.add(t);
							
						 }
						 break;
					 case"java.lang.Double":
						 if(((Double)valueInTuple).compareTo((Double)value)>0) {
							 result.add(t);
							
						 }
						 break;
					 case "java.lang.String":
						 if(((String)valueInTuple).compareTo((String)value)>0) {
							 result.add(t);
							 
						 } break;
					 case "java.lang.Date":
						 if(((Date)valueInTuple).compareTo((Date)value)>0) {
							 result.add(t);
						
						 } break;
						default: break; 
					 } 
				 }
				 Page.serialize(page);
			 }
			 
			 break;
		 case "<":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInTuple = t.ColNameValue.get(colName);
					 String type = valueInTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInTuple).compareTo((Integer)value)<0) {
							 result.add(t);
							 
						 } break;
						 
					 case"java.lang.Double":
						 if(((Double)valueInTuple).compareTo((Double)value)<0) {
							 result.add(t);
							
						 } break;
						 
					 case "java.lang.String":
						 if(((String)valueInTuple).compareTo((String)value)<0) {
							 result.add(t);
							
						 } break;
					 case "java.lang.Date":
						 if(((Date)valueInTuple).compareTo((Date)value)<0) {
							 result.add(t);
							
						 }  break;
					 default: break;
					 } 
				 }
				 Page.serialize(page);
			 }
			 break;
		 case ">=":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInTuple = t.ColNameValue.get(colName);
					 String type = valueInTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInTuple).compareTo((Integer)value)>=0) {
							 result.add(t);
							 
						 } break;
						 
					 case"java.lang.Double":
						 if(((Double)valueInTuple).compareTo((Double)value)>=0) {
							 result.add(t);
							 
						 } break;
						 
					 case "java.lang.String":
						 if(((String)valueInTuple).compareTo((String)value)>=0) {
							 result.add(t);
							
						 } break;
					 case "java.lang.Date":
						 if(((Date)valueInTuple).compareTo((Date)value)>=0) {
							 result.add(t);
							 
						 } break;
					default: break;	 
					 } 
				 }
				 Page.serialize(page);
			 }
			 break;
		 case "<=":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInTuple = t.ColNameValue.get(colName);
					 String type = valueInTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInTuple).compareTo((Integer)value)<=0) {
							 result.add(t);
							 
						 }
						 break;
					 case"java.lang.Double":
						 if(((Double)valueInTuple).compareTo((Double)value)<=0) {
							 result.add(t);
							
						 } break;
						 
					 case "java.lang.String":
						 if(((String)valueInTuple).compareTo((String)value)<=0) {
							 result.add(t);
							
						 } break;
					 case "java.lang.Date":
						 if(((Date)valueInTuple).compareTo((Date)value)<=0) {
							 result.add(t);
							
						 } break;
					default: break;	 
					 } 
				 }
				 Page.serialize(page);
			 }
			 break;
		 default: break;
		 
	 }
		 return result;
		
		
	 }
	 
	 
	 public void displayIndex(String indexName) throws DBAppException {
		octTree<String> index = octTree.deserialize(indexName);
		index.display();
		octTree.serialize(index, indexName);
	 }
	

	public void createIndex(String strarrColName) throws DBAppException {
		Hashtable<String, String> ColNameType = readTable(); 
		
		BPlusTree tree = new BPlusTree(this.TableName, strarrColName+" "+ "Index", 4);
		

		if(!pages.isEmpty()) {
			for(Integer key: pages.keySet()) {
				Page page = Page.deserialize(pages.get(key));
				
				for(Tuple t: page.tuples) {
//					Object valueX = t.ColNameValue.get(strarrColName);
					tree.insert(t.getPrimaryKey(), t.getColNameValue());
				}
				
				
				Page.serialize(page);
				}
		}
		String indexName = TableName+"_"+ strarrColName;
		Indexes.put(numberOfIndexes, indexName );
		numberOfIndexes++;
		BPlusTree.serialize(tree, indexName);
	
		
		
		
	}

	public ArrayList<Tuple> selectFromIndex(String indexName, SQLTerm[] arrSQLTerms) throws DBAppException {
			
			ArrayList<Tuple> result = new ArrayList<>();
//			
			String columnName1 = arrSQLTerms[0]._strColumnName;
			String columnName2 = arrSQLTerms[1]._strColumnName;
			String columnName3 = arrSQLTerms[2]._strColumnName;
			
			String op1 = arrSQLTerms[0]._strOperator;
			String op2 = arrSQLTerms[1]._strOperator;
			String op3 = arrSQLTerms[2]._strOperator;
			
			Object v1 = arrSQLTerms[0]._objValue;
			Object v2 = arrSQLTerms[1]._objValue;
			Object v3 = arrSQLTerms[2]._objValue;
			if(op1.equals("=") && op2.equals("=") && op3.equals("=")) {
				octTree<String> index = octTree.deserialize(indexName);
				Object x;
				Object y;
				Object z;
				if(index.colName1.equals(columnName1)) {
					x = v1;
				}
				else if(index.colName1.equals(columnName2)) {
					x = v2;
				}
				else {
					x =v3;
				}
				if(index.colName2.equals(columnName1)) {
					y =v1;
				}
				else if(index.colName2.equals(columnName2)) {
					y =v3;
				}
				else {
					y =v3;
				}
				if(index.colName3.equals(columnName1)) {
					z =v1;
				}
				else if(index.colName3.equals(columnName2)) {
					z =v2;
				}
				else {
					z =v3;
				}
				octPoint tuplesPathes = index.get(x,y,z);
				for(String path : tuplesPathes.duplicates) {
					String[] pageAndKey = path.split(",");
					String pagePath = pageAndKey[0];
					String key = pageAndKey[1];
					String pkType =  getPrimaryKeyType();
					Page page = Page.deserialize(pagePath);
					Object primaryKey = parse(key, pkType);
					int i = page.binarysearch(primaryKey, pkType);
					Tuple t = page.tuples.get(i);
					result.add(t);	
				}	
			octTree.serialize(index, indexName);
			}
			else {
				octTree<String> index = octTree.deserialize(indexName);
				Hashtable<String, String> columnNameOperator = new Hashtable<>();
				Hashtable<String, Object> columnNameValue = new Hashtable<>();
				columnNameOperator.put(columnName1, op1);
				columnNameOperator.put(columnName2, op2);
				columnNameOperator.put(columnName3, op3);
				
				columnNameValue.put(columnName1, v1 );
				columnNameValue.put(columnName2, v2 );
				columnNameValue.put(columnName3, v3 );
				
				ArrayList<octPoint> tuplesPathes =  index.selectWithRange(columnNameOperator, columnNameValue);
				for(octPoint point : tuplesPathes ) {
					for(String path : point.duplicates) {
						String[] pageAndKey = path.split(",");
						String pagePath = pageAndKey[0];
						String key = pageAndKey[1];
						String pkType =  getPrimaryKeyType();
						Page page = Page.deserialize(pagePath);
						Object primaryKey = parse(key, pkType);
						int i = page.binarysearch(primaryKey, pkType);
						Tuple t = page.tuples.get(i);
						result.add(t);	
					}	
				}
				octTree.serialize(index, indexName);
			}
			return result;
				
	}

	
	
	
	
}
