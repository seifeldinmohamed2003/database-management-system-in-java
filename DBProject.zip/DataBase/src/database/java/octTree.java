package database.java;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

public class octTree<T> implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private octPoint point;

    private octPoint topLeftFront, bottomRightBack;

    private octTree<T>[] children = new octTree[8];
    
    

    String tableName;
    String colName1;
    String colName2;
    String colName3;
    
    
    public void display() {
    	if(point == null) {
    		for(octTree<T> child : children) {
    			child.display();
    		}
    	}
    	else {
    		point.display();
    	}
    	
    }
   
    
    
    public octTree(){
        point = new octPoint();
    }
   
	
	public void setColumnNames(String colName1, String colName2, String colName3) {
		this.colName1 = colName1;
		this.colName2 = colName2;
		this.colName3 = colName3;
	}
	
	
	
	public  String getTableName() {
		return tableName;
	}


	public String getColName1() {
		return colName1;
	}


	public String getColName2() {
		return colName2;
	}


	public String getColName3() {
		return colName3;
	}
	


	public static void serialize(octTree<String> octTree, String indexName) throws DBAppException {
		try {
//			System.out.println("IO||||\t serialize:table:"+table.getTableName());
			
			FileOutputStream fileOut = new FileOutputStream("./src/main/resources/data/" + indexName + ".ser");
			
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(octTree);
			out.close();
			fileOut.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new DBAppException("IO Exception while writing to disk\t Index" + indexName);
		}
	}
	

	public static octTree<String> deserialize(String indexName) throws DBAppException {
		//indexName is tableName + colName1 + colName2+ colName3 
		//the three columns that has the index on
		
		try {
//			System.out.println("IO||||\t deserialize:table:"+tableName);
			FileInputStream fileIn = new FileInputStream("./src/main/resources/data/"+indexName+".ser");
		
			
			ObjectInputStream in = new ObjectInputStream(fileIn);

			octTree<String> octTree = (octTree<String>) in.readObject();
			in.close();
			fileIn.close();

			return octTree;
		} catch (IOException e) {
			e.printStackTrace();
			throw new DBAppException(
					"IO Exception | Probably wrong Index name (tried to operate on a index that does not exist !");
		} catch (ClassNotFoundException e) {
			throw new DBAppException("Class Not Found Exception");
		}
	}
	

    public octTree(Object x, Object y, Object z, String object){
    	
        point = new octPoint(x, y, z);
        point.duplicates.add(object);
    }
    
    public boolean inBoundries(Object x, Object y, Object z) {
    	 Object minX = topLeftFront.getX() ;
         Object maxX = bottomRightBack.getX();
         Object minY = topLeftFront.getY();
         Object maxY = bottomRightBack.getY();
         Object minZ = topLeftFront.getZ();
         Object maxZ = bottomRightBack.getZ();

    	 if(x instanceof Integer) {
    			if( (Integer)x < (Integer)minX || (Integer)x > (Integer)maxX)
    				{
    				   return false;
    				   
    				}}
     		  if  (x instanceof String) {
     			  if (((String)x).compareTo((String)minX) < 0 ||((String)x).compareTo((String)maxX) > 0)
{
	return false;
	
}}
     		   if (x instanceof Double ){
     			 if ((Double)x < (Double)minX ||(Double)x > (Double)maxX )
     		   {
     			   return false;
     		   }
     			   
     		   }
     				  
     		    if (x instanceof Date){
     		    		if (((Date)x).before((Date)minX) || ((Date)x).after((Date)maxX) ) {
     		    	return false;
     		    }}
     		    
     		 if   (y instanceof Integer ) {
     			if((Integer)y < (Integer)minY || (Integer)y > (Integer)maxY)
     			{
     				return false;
     			}
     		 }
     		    		
     		   if (y instanceof String) {
     			  if(((String)y).compareTo((String)minY) < 0 ||((String)y).compareTo((String)maxY) > 0 )
     			  {
     				  return false;
     			  }}
     		   
     		   if (y instanceof Double ) {
     			   if( (Double)y < (Double)minY ||(Double)y > (Double)maxY ) 
     			   {
     				   return false;
     			   }}
     		    if (y instanceof Date ) {
     		    	if(((Date)y).before((Date)minY) || ((Date)y).after((Date)maxY)  ) {
     		    		return false;
     		    	}}
     		    if (z instanceof Integer) {
     		    	if ((Integer)z < (Integer)minZ || (Integer)z > (Integer)maxZ ) 
     		    	{
     		    		return false;
     		    	}}
     		   if (z instanceof String) {
     			   if(((String)z).compareTo((String)minZ) < 0  ||((String)z).compareTo((String)maxZ) > 0 )
{
	return false;
}}
     		   if (z instanceof Double ){
     			   
     			   if((Double)z < (Double)minZ || (Double)z > (Double)maxZ ) 
     			   {
     				   return false;
     			   }
     			   }
     		   if (z instanceof Date) {
     			   if (((Date)z).before((Date)minZ) ||((Date)z).after((Date)maxZ) ) {
     				   return false;
     		   }}
    		 return true;
    }

    public Object getMiddleObject(Object o, Object min, Object max) {
    	Object mid = null;
    	
    	if(o instanceof Integer) {
        	 mid = (Integer)(((Integer)min + (Integer)max)/2);
        }
        else if(o instanceof String) {
        	String minxString = (String) min;
        	String maxString = (String) max;
        	 if(minxString.length()> maxString.length()) {
        		for(int i = maxString.length(); i < minxString.length(); i++) {
        			maxString += minxString.charAt(i);
        		}
        	}
        	else if(minxString.length() < maxString.length()) {
        		for(int i = minxString.length(); i < maxString.length(); i++) {
        			minxString += maxString.charAt(i);
        		}
        	}
        	 int N = minxString.length();
        	 mid = getMiddleString(minxString, maxString, N);
        }
        else if(o instanceof Double) {
        	 mid = (Double)(((Double)min + (Double)max)/2);
        }
        else if(o instanceof Date) {
        	Date date1 = (Date) min;
            Date date2 = (Date) max;
            mid = new Date((date1.getTime() + date2.getTime()) / 2);
        }
		return mid;
    }
    
    public int findPos(Object x, Object y, Object z, Object midx, Object midy, Object midz) {
    	int pos;
    	 if((x instanceof Integer && (Integer)x <= (Integer)midx ) ||
    	         	(x instanceof String && ((String)x).compareTo((String)midx) <= 0 ) ||
    	     		(x instanceof Double && (Double)x <= (Double)midx  ) ||
    	     		(x instanceof Date && (((Date)x).before((Date)midx) || ((Date)x).equals((Date)midx)))){
    	             if((y instanceof Integer && (Integer)y <= (Integer)midy ) ||
    	                 	(y instanceof String && ((String)y).compareTo((String)midy) <= 0 ) ||
    	             		(y instanceof Double && (Double)y <= (Double)midy  ) ||
    	             		(y instanceof Date && (((Date)y).before((Date)midy) || ((Date)y).equals((Date)midy)))){
    	             	if((z instanceof Integer && (Integer)z <= (Integer)midz ) ||
    	                     	(z instanceof String && ((String)z).compareTo((String)midz) <= 0 ) ||
    	                 		(z instanceof Double && (Double)z <= (Double)midz  ) ||
    	                 		(z instanceof Date && (((Date)z).before((Date)midz) || ((Date)z).equals((Date)midz))))
    	                     pos = OctLocations.TopLeftFront.getNumber();
    	                 else
    	                     pos = OctLocations.TopLeftBottom.getNumber();
    	             }else{
    	             	if((z instanceof Integer && (Integer)z <= (Integer)midz ) ||
    	                     	(z instanceof String && ((String)z).compareTo((String)midz) <= 0 ) ||
    	                 		(z instanceof Double && (Double)z <= (Double)midz  ) ||
    	                 		(z instanceof Date && (((Date)z).before((Date)midz) || ((Date)z).equals((Date)midz))))
    	                     pos = OctLocations.BottomLeftFront.getNumber();
    	                 else
    	                     pos = OctLocations.BottomLeftBack.getNumber();
    	             }
    	         }else{
    	         	if((y instanceof Integer && (Integer)y <= (Integer)midy ) ||
    	                 	(y instanceof String && ((String)y).compareTo((String)midy) <= 0 ) ||
    	             		(y instanceof Double && (Double)y <= (Double)midy  ) ||
    	             		(y instanceof Date && (((Date)y).before((Date)midy) || ((Date)y).equals((Date)midy)))){
    	             	if((z instanceof Integer && (Integer)z <= (Integer)midz ) ||
    	                     	(z instanceof String && ((String)z).compareTo((String)midz) <= 0 ) ||
    	                 		(z instanceof Double && (Double)z <= (Double)midz  ) ||
    	                 		(z instanceof Date && (((Date)z).before((Date)midz) || ((Date)z).equals((Date)midz))))
    	                     pos = OctLocations.TopRightFront.getNumber();
    	                 else
    	                     pos = OctLocations.TopRightBottom.getNumber();
    	             }else {
    	             	if((z instanceof Integer && (Integer)z <= (Integer)midz ) ||
    	                     	(z instanceof String && ((String)z).compareTo((String)midz) <= 0 ) ||
    	                 		(z instanceof Double && (Double)z <= (Double)midz  ) ||
    	                 		(z instanceof Date && (((Date)z).before((Date)midz) || ((Date)z).equals((Date)midz))))
    	                     pos = OctLocations.BottomRightFront.getNumber();
    	                 else
    	                     pos = OctLocations.BottomRightBack.getNumber();
    	             }
    	         }
    	 return pos;
    }
    
    public octTree(Object x1, Object y1, Object z1, Object x2, Object y2, Object z2) throws DBAppException {
    	
    	
    	 if(x2 instanceof Integer) {
 			if( (Integer)x2 < (Integer)x1)
 				{
 				throw new DBAppException("The bounds are not properly set!");
 				   
 				}}
  		  if  (x2 instanceof String) {
  			  if (((String)x2).compareTo((String)x1) < 0)
{
  				throw new DBAppException("The bounds are not properly set!");	
}}
  		   if (x2 instanceof Double ){
  			 if ((Double)x2 < (Double)x1)
  		   {
  				throw new DBAppException("The bounds are not properly set!");
  		   }
  			   
  		   }
  				  
  		    if (x2 instanceof Date){
  		    		if (((Date)x2).before((Date)x1)) {
  		    			throw new DBAppException("The bounds are not properly set!");
  		    }}
  		    
  		 if   (y2 instanceof Integer ) {
  			if((Integer)y2 < (Integer)y1)
  			{
  				throw new DBAppException("The bounds are not properly set!");
  			}
  		 }
  		    		
  		   if (y2 instanceof String) {
  			  if(((String)y2).compareTo((String)y1) < 0 )
  			  {
  				throw new DBAppException("The bounds are not properly set!");
  			  }}
  		   
  		   if (y2 instanceof Double ) {
  			   if( (Double)y2 < (Double)y1 ) 
  			   {
  				 throw new DBAppException("The bounds are not properly set!");
  			   }}
  		    if (y2 instanceof Date ) {
  		    	if(((Date)y2).before((Date)y1) ){
  		    		throw new DBAppException("The bounds are not properly set!");
  		    	}}
  		    if (z2 instanceof Integer) {
  		    	if ((Integer)z2 < (Integer)z1) 
  		    	{
  		    		throw new DBAppException("The bounds are not properly set!");
  		    	}}
  		   if (z2 instanceof String) {
  			   if(((String)z2).compareTo((String)z1) < 0 )
{
  				 throw new DBAppException("The bounds are not properly set!");
}}
  		   if (z2 instanceof Double ){
  			   
  			   if((Double)z2 < (Double)z1) 
  			   {
  				 throw new DBAppException("The bounds are not properly set!");
  			   }
  			   }
  		   if (z2 instanceof Date) {
  			   if (((Date)z2).before((Date)z1))  {
  				 throw new DBAppException("The bounds are not properly set!");
  		   }}
    		
            
  

        point = null;
        topLeftFront = new octPoint(x1, y1, z1);
        bottomRightBack = new octPoint(x2, y2, z2);

        for (int i = 0; i <= 7; i++){
            children[i] = new octTree<>();
        }
    }

    public static String getMiddleString(String S, String T , int N) {
    	String middle = "";
  
    			// Stores the base 26 digits after addition
    			int[] a1 = new int[N + 1];

    			for (int i = 0; i < N; i++) {
    				a1[i + 1] = (int)S.charAt(i) - 97
    							+ (int)T.charAt(i) - 97;
    			}

    			// Iterate from right to left
    			// and add carry to next position
    			for (int i = N; i >= 1; i--) {
    				a1[i - 1] += (int)a1[i] / 26;
    				a1[i] %= 26;
    			}

    			// Reduce the number to find the middle
    			// string by dividing each position by 2
    			for (int i = 0; i <= N; i++) {

    				// If current value is odd,
    				// carry 26 to the next index value
    				if ((a1[i] & 1) != 0) {

    					if (i + 1 <= N) {
    						a1[i + 1] += 26;
    					}
    				}

    				a1[i] = (int)a1[i] / 2;
    			}

    			for (int i = 1; i <= N; i++) {
    				middle += ((char)(a1[i] + 97));
    			}
    			
    			return middle;
    			
    		}

    
    public void insert(Object x, Object y, Object z, String object_2) throws DBAppException {
        if(find(x, y, z)){
        	//the point is duplicated
        	octPoint point = get(x, y, z);
        	if(point.duplicates.contains(object_2)) {
        		//with the exact page,key
        		throw new DBAppException("Point already exists in the tree. X: " + x + " Y: " + y + " Z: " + z );
        	}
        	point.duplicates.add(object_2);
        	return;
        	
        }
        if(!inBoundries(x,y,z)) {
   		 throw new DBAppException("the point to be inserted is out of bound!");
   	 }
   	
   	 	Object minX = topLeftFront.getX() ;
        Object maxX = bottomRightBack.getX();
        Object minY = topLeftFront.getY();
        Object maxY = bottomRightBack.getY();
        Object minZ = topLeftFront.getZ();
        Object maxZ = bottomRightBack.getZ();

       
   	    Object midx = getMiddleObject(x, minX, maxX);
        Object midy = getMiddleObject(y, minY, maxY);
        Object midz = getMiddleObject(z, minZ, maxZ); 
        
      
    		  
        int pos = findPos(x,y,z,midx, midy,midz);

        if(children[pos].point == null){
            children[pos].insert(x, y, z, object_2);
        }
        else if(children[pos].point.isNullified()){
            children[pos] = new octTree<>(x, y, z, object_2);
        }
        else{
            Object x_ = children[pos].point.getX();
            Object y_ = children[pos].point.getY();
            Object z_ = children[pos].point.getZ();
            ArrayList<String> objects_ = children[pos].point.duplicates;
            children[pos] = null;
            if(pos == OctLocations.TopLeftFront.getNumber()){
                children[pos] = new octTree<>(topLeftFront.getX(), topLeftFront.getY(), topLeftFront.getZ(), midx, midy, midz);
            }
            else if(pos == OctLocations.TopRightFront.getNumber()){
                children[pos] = new octTree<>(midx, topLeftFront.getY(), topLeftFront.getZ(), bottomRightBack.getX(), midy, midz);
            }
            else if(pos == OctLocations.BottomRightFront.getNumber()){
                children[pos] = new octTree<>(midx, midy, topLeftFront.getZ(), bottomRightBack.getX(), bottomRightBack.getY(), midz);
            }
            else if(pos == OctLocations.BottomLeftFront.getNumber()){
                children[pos] = new octTree<>(topLeftFront.getX(), midy, topLeftFront.getZ(), midx, bottomRightBack.getY(), midz);
            }
            else if(pos == OctLocations.TopLeftBottom.getNumber()){
                children[pos] = new octTree<>(topLeftFront.getX(), topLeftFront.getY(),midz, midx, midy, bottomRightBack.getZ());
            }
            else if(pos == OctLocations.TopRightBottom.getNumber()){
                children[pos] = new octTree<>(midx, topLeftFront.getY(), midz, bottomRightBack.getX(), midy, bottomRightBack.getZ());
            }
            else if(pos == OctLocations.BottomRightBack.getNumber()){
                children[pos] = new octTree<>(midx, midy, midz, bottomRightBack.getX(), bottomRightBack.getY(), bottomRightBack.getZ());
            }
            else if(pos == OctLocations.BottomLeftBack.getNumber()){
                children[pos] = new octTree<>(topLeftFront.getX(), midy, midz, midx, bottomRightBack.getY(), bottomRightBack.getZ());
            }
            
            if(objects_.size()==1) {
            	children[pos].insert(x_, y_, z_, objects_.get(0));
            }
            else {
            	for(String s: objects_) {
            		children[pos].insert(x_, y_, z_, s);
            	}
            }
            
            children[pos].insert(x, y, z, object_2);
        }
    }
    
//    public static Object incrementObject (Object object ) {
//    	if(object instanceof Integer ) {
//    		return ((Integer)object) + 1;
//    	}
//    	else if (object instanceof String) {
//    		String str = (String) object;
//    		char[] charArray = str.toCharArray();
//    	    int i = charArray.length - 1;
//    	    
//    	    while (i >= 0 && charArray[i] == 'z') {
//    	        charArray[i] = 'a';
//    	        i--;
//    	    }
//    	    
//    	    if (i >= 0) {
//    	        charArray[i]++;
//    	    }
//    	    
//    	    return new String(charArray);
//    	}
//    	else if(object instanceof Double) {
//    		return ((Double)object) + 0.01;
//    	}
//    	else if(object instanceof Date) {
//    		// create a Calendar instance and set it to the given Date
//    		Calendar calendar = Calendar.getInstance();
//    		calendar.setTime((Date)object);
//
//    		// increment the date by one day
//    		calendar.add(Calendar.DAY_OF_YEAR, 1);
//
//    		// get the updated Date object
//    		Date updatedDate = calendar.getTime();
//
//    		return updatedDate;
//    	}
//		return object;
//    }
//    
     public boolean find(Object x, Object y, Object z){
    	 
    	 if(!inBoundries(x,y,z)) {
    		 return false;
    	 }
    	
    	 Object minX = topLeftFront.getX() ;
         Object maxX = bottomRightBack.getX();
         Object minY = topLeftFront.getY();
         Object maxY = bottomRightBack.getY();
         Object minZ = topLeftFront.getZ();
         Object maxZ = bottomRightBack.getZ();

        
    	 Object midx = getMiddleObject(x, minX, maxX);
         Object midy = getMiddleObject(y, minY, maxY);
         Object midz = getMiddleObject(z, minZ, maxZ); 
         
       
     		  
         int pos = findPos(x,y,z,midx, midy,midz);
         
        

        if(children[pos].point == null)
            return children[pos].find(x, y, z);
        if(children[pos].point.isNullified())
            return false;
        return (x.equals(children[pos].point.getX())) && (y.equals(children[pos].point.getY())) && (z.equals(children[pos].point.getZ()));
    }

    public octPoint get(Object x, Object y, Object z){
    	 if(!inBoundries(x,y,z)) {
    		 return null;
    	 }
    	
    	 Object minX = topLeftFront.getX() ;
         Object maxX = bottomRightBack.getX();
         Object minY = topLeftFront.getY();
         Object maxY = bottomRightBack.getY();
         Object minZ = topLeftFront.getZ();
         Object maxZ = bottomRightBack.getZ();

        
    	 Object midx = getMiddleObject(x, minX, maxX);
         Object midy = getMiddleObject(y, minY, maxY);
         Object midz = getMiddleObject(z, minZ, maxZ); 
         
       
     		  
         int pos = findPos(x,y,z,midx, midy,midz);

        if(children[pos].point == null)
            return children[pos].get(x, y, z);
        if(children[pos].point.isNullified())
            return null;
        if(x.equals(children[pos].point.getX()) && y.equals(children[pos].point.getY()) && z.equals(children[pos].point.getZ())){
            return children[pos].point;
        }

        return null;
    }

    public boolean remove(Object x, Object y, Object z, String path){
    	 if(!inBoundries(x,y,z)) {
    		 return false;
    	 }
    	
    	 Object minX = topLeftFront.getX() ;
         Object maxX = bottomRightBack.getX();
         Object minY = topLeftFront.getY();
         Object maxY = bottomRightBack.getY();
         Object minZ = topLeftFront.getZ();
         Object maxZ = bottomRightBack.getZ();

        
    	 Object midx = getMiddleObject(x, minX, maxX);
         Object midy = getMiddleObject(y, minY, maxY);
         Object midz = getMiddleObject(z, minZ, maxZ); 
         
       
     		  
         int pos = findPos(x,y,z,midx, midy,midz);

        if(children[pos].point == null)
            return children[pos].remove(x, y, z, path);
        if(children[pos].point.isNullified())
            return false;
        if(x.equals(children[pos].point.getX()) && y.equals(children[pos].point.getY()) && z.equals(children[pos].point.getZ())){
            if(children[pos].point.duplicates.contains(path)) {
            	children[pos].point.duplicates.remove(path);
            }
            if(children[pos].point.duplicates.isEmpty()) {
            	children[pos] = new octTree<>();
            }
        }
        return false;
    }


	public void setTableName(String tableName) {
		this.tableName = tableName;
		
	}
	
	public static void main(String[] args) {
		
	}

	public boolean compareTo(Object o , String operator, Object value) {
		switch(operator) {
		case "=": 
			return o.equals(value);
		case ">":
			switch(o.getClass().getName()) {
			case "java.lang.Integer":
				 return(((Integer)o).compareTo((Integer)value)>0);
			 case"java.lang.Double":
				return(((Double)o).compareTo((Double)value)>0);
			 case "java.lang.String":
				 return(((String)o).compareTo((String)value)>0) ;
					 
			 case "java.lang.Date":
				 return(((Date)o).compareTo((Date)value)>0);
					
			}
		case "<":
			switch(o.getClass().getName()) {
			case "java.lang.Integer":
				 return(((Integer)o).compareTo((Integer)value)<0);
			 case"java.lang.Double":
				return(((Double)o).compareTo((Double)value)<0);
			 case "java.lang.String":
				 return(((String)o).compareTo((String)value)<0) ;
					 
			 case "java.lang.Date":
				 return(((Date)o).compareTo((Date)value)<0);
					
			}
		case ">=":
			switch(o.getClass().getName()) {
			case "java.lang.Integer":
				 return(((Integer)o).compareTo((Integer)value)>=0);
			 case"java.lang.Double":
				return(((Double)o).compareTo((Double)value)>=0);
			 case "java.lang.String":
				 return(((String)o).compareTo((String)value)>=0) ;
					 
			 case "java.lang.Date":
				 return(((Date)o).compareTo((Date)value)>=0);
					
			}
		case "<=":
			switch(o.getClass().getName()) {
			case "java.lang.Integer":
				 return(((Integer)o).compareTo((Integer)value)<=0);
			 case"java.lang.Double":
				return(((Double)o).compareTo((Double)value)<=0);
			 case "java.lang.String":
				 return(((String)o).compareTo((String)value)<=0) ;
					 
			 case "java.lang.Date":
				 return(((Date)o).compareTo((Date)value)<=0);
					
			}
		case "!=":
			return !(o.equals(value));
		}
		return false;
				
				
		
	}

	public ArrayList<octPoint> selectWithRange(Hashtable<String, String> columnNameOperator, Hashtable<String, Object> columnNameValue) {
		ArrayList<octPoint>result=new ArrayList<>();
		String op1 = columnNameOperator.get(colName1);
		String op2 = columnNameOperator.get(colName2);
		String op3 = columnNameOperator.get(colName3);
		
		Object value1 = columnNameValue.get(colName1);
		Object value2 = columnNameValue.get(colName2);
		Object value3 = columnNameValue.get(colName3);
		
		result = selectWithRangehelper(op1,op2,op3,value1,value2,value3, result);
		
		return result;
	        
		
		
	}



	private ArrayList<octPoint> selectWithRangehelper(String op1, String op2, String op3, Object value1, Object value2,
			Object value3, ArrayList<octPoint> result) {
		
		for(octTree<T> child: children) {
			
			 if(child.point == null) {
		            result= child.selectWithRangehelper(op1, op2, op3, value1, value2, value3, result);
			 }
			 else if(!child.point.isNullified()) {
				child.point.display();
		        Object xValue = child.point.getX();
		        Object yValue = child.point.getY();
		        Object zValue = child.point.getZ();
		        if (compareTo(xValue, op1, value1)&& compareTo(yValue,op2,value2)&&compareTo(zValue, op3, value3)) {
		        	result.add(child.point);
		    
		        }
			 }
			}
		return result;
	}
    
    
    
}

 

	