package database.java;

import java.io.Serializable;
import java.util.ArrayList;

public class octPoint implements Serializable{

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private Object x;
	    private Object y;
	    private Object z;
	    
	   
	    ArrayList<String> duplicates = new ArrayList<>();

	    private boolean nullify = false;

	    public void display() {
	    	
	    		if(!nullify) {
	    		System.out.println("( "+ x + " , " + y + " , " + z + " ) "+"-->");
	    		
	    		for(String string: duplicates) {
	    			System.out.println(string);
	    		}
	    		}
	    	}			
	    	
	    
	    
	    public octPoint(Object x, Object y, Object z){
	        this.x = x;
	        this.y = y;
	        this.z = z;
	    }

	    public octPoint(){
	        nullify = true;
	    }

	   

		public ArrayList<String> getDuplicates() {
			return duplicates;
		}

		public void setDuplicates(ArrayList<String> duplicates) {
			this.duplicates = duplicates;
		}

		public Object getX(){
	        return x;
	    }

	    public Object getY(){
	        return y;
	    }

	    public Object getZ(){
	        return z;
	    }

	    public boolean isNullified(){
	        return nullify;
	    }

}
