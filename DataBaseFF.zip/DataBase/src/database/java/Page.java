package database.java;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;


import java.util.Properties;



public class Page  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7064945789775916652L;
	Object minPKey;
	Object maxPKey;
	int maxSize; //max no. of rows
	Vector<Tuple> tuples;
	String pageName;
	
	
	public Page(String pageName , Object minPKey1, Object maxPKey1 ) {
		this.maxSize = setMaxPageSize();
		this.minPKey = minPKey1;
		this.maxPKey = maxPKey1;
		this.tuples = new Vector<>(maxSize);
		this.pageName = pageName;
	}
	
	public static void serialize(Page page) throws DBAppException {
		try {
//			System.out.println("IO||||\t serialize:table:"+table.getTableName());
			FileOutputStream fileOutput = new FileOutputStream("./src/main/resources/data/" + page.pageName + ".ser");
		
				
			
			ObjectOutputStream out = new ObjectOutputStream(fileOutput);
			out.writeObject(page);
			out.close();
			fileOutput.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new DBAppException("IO Exception when writing to the disk\t Page" + page.pageName);
		}
	}
	
	public static Page deserialize(String pageName) throws DBAppException {
		try {
//			System.out.println("IO||||\t deserialize:table:"+tableName);
			FileInputStream fileInput = new FileInputStream("./src/main/resources/data/" + pageName + ".ser");
			
				
			
			ObjectInputStream in = new ObjectInputStream(fileInput);

			Page page = (Page) in.readObject();
			in.close();
			fileInput.close();

			return page;
		} catch (IOException e) {
			e.printStackTrace();
			throw new DBAppException(
					"IO Exception | Wrong page name (Page does not exist !");
		} catch (ClassNotFoundException e) {
			throw new DBAppException("Class Not Found");
		}
	}
	
	
	
	
	
	// this method sets the max page size to the max size provided in the file "maxRows.csv"
	public int setMaxPageSize() { 
		 Properties p = new Properties();
		 try (FileInputStream FIS = new FileInputStream("./src/main/resources/DBApp.config")) {
	            p.load(FIS);
	            // You can now access the properties using the getProperty method
	            String maxsize = p.getProperty("MaximumRowsCountinTablePage");
	            return Integer.parseInt(maxsize);

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		  return 0;		
	}
	
	public boolean isEmpty() {
		return tuples.isEmpty();
	}
	
	public boolean isFull() {
		return tuples.size() == maxSize;
	}
	
	public Tuple getTuple(int index) {
		if(index<0 || index>=tuples.size()) {
			return null;
		}
		return tuples.get(index);
	}
	
	public int size() {
		return tuples.size();
	}
	
	public void insert(Tuple newTuple , int index) {
		//if(index==0){
		if(index==size()) {
			tuples.add(index, newTuple);
			updateMinMax();
		}
		else {
		tuples.set(index, newTuple);
		updateMinMax();
		}
		
	}
	
	public void updateTuple(Object pk, Hashtable<String, Object> newValue, String type) throws DBAppException {
		int index = binarySearch(pk, type);
		Tuple tuple = tuples.get(index);
		for (String columnName : newValue.keySet()) {
			  if (tuple.ColNameValue.containsKey(columnName)) {
				 if(columnName.equals(tuple.pkName)) {
					 throw new DBAppException("Primary key cannot be updates");
				 }
				 else {
					 tuple.ColNameValue.put(columnName, newValue.get(columnName));
				 }
			  }
			  else {
				  throw new DBAppException("Incorrect column name");
			  }
			}
	}
	
	public void shift(int index) {
		int last = tuples.size() -1;
		if(tuples.size()<maxSize) {
		   tuples.add(tuples.get(last));
		}
		for(int i = last; i > index; i--) {
			tuples.set(i, tuples.get(i-1));
		}
	}
	
	public int binarySearch(Object pk, String type) {
		 int s = 0; 
		 int e = tuples.size()-1;
		
		 while(s <= e) {
			 int mid = s + (e - s)/2;
			 Object midPK = (tuples.get(mid)).Pkey;
			 if(midPK.equals(pk)) {
				return mid;
			 }
			 else {
					switch (type) {
					case "java.lang.Integer":{
						if (((Integer) pk).compareTo((Integer)midPK) > 0 ) {
							s = mid+1;
						}
						else if (((Integer) pk).compareTo((Integer)midPK) < 0 ){
							e = mid -1;
						}
						break;
					}
					case "java.lang.Double":{
						if (((Double) pk).compareTo((Double)midPK) > 0) {
							s = mid+1;
						}
						else if (((Double) pk).compareTo((Double)midPK) < 0 ){
							e = mid -1;
						}
						break;
					}
						
						
					case "java.lang.String":{
						if (((String) pk).compareTo((String)midPK) > 0) {
							s = mid+1;
						}
						else if (((String) pk).compareTo((String)midPK) < 0 ){
							e = mid -1;
						}
						break;
					}
						default: break;
					
			 }
			 }
			 
			
		 }
		 return s;
	}
	
	public boolean delete1(Hashtable<String, Object> htblColNameValue,Object pk, String type, Hashtable<Integer, String> indexes) throws DBAppException {
		int i = binarySearch(pk, type);
		
		if(i >= tuples.size()) {
			throw new DBAppException("tuple does not exist");
		}
//		System.out.println(tuples.get(i).primaryKey);
//		System.out.println(pk);
		if(!tuples.get(i).Pkey.equals(pk)) {
			throw new DBAppException("tuple does not exist");	
}
		for(Integer k: indexes.keySet()) {
			String indexName = indexes.get(k);
		BPlusTree tree = BPlusTree.deserialize(indexName);
		tree.delete((int)pk );
		BPlusTree.serialize(tree, indexName);
		}
		tuples.remove(i);
		return true;
		
	}


	public boolean delete1(Hashtable<String, Object> htblColNameValue, Hashtable<Integer, String> indexes ) throws DBAppException  {
		//searching linearly tuple by tuple if the column values matches the given column values.if yes delete it iterating over the given hashtable of conditions since the tuple is a hashtable and the conditions are in hashtable where both keys are colnames. 
       boolean flag1 = false;
		for(int i = 0; i< size(); i++) {
			Tuple tuple = tuples.get(i);
			boolean flag2 = true;
			for(String key: htblColNameValue.keySet()) {
				if(!tuple.ColNameValue.containsKey(key)) {
					throw new DBAppException("wrong column name");
				}
				flag2 = flag2 && (tuple.ColNameValue.get(key)).equals(htblColNameValue.get(key));
			}
			if(flag2) {
				for(Integer key: indexes.keySet()) {
					String indexName = indexes.get(key);
					BPlusTree tree = BPlusTree.deserialize(indexName);
					tree.delete(tuple.getPrimaryKey());
					BPlusTree.serialize(tree, indexName);				
					}		
				tuples.remove(i);
				flag1=true;
				i--;
			}
		}
		updateMinMax();
		return flag1;
	}
	
	public void updateMinMax() {
		if(size() == 0) {
			minPKey = null;
			maxPKey = null;
		}
		else{
		minPKey = tuples.get(0).Pkey;
		maxPKey = tuples.get(size()-1).Pkey;
		}
	}
	public String toString()
	{
		return tuples.toString();
	}

	public void updateTupleWithIndex(Object pk, Hashtable<String, Object> newValue, String pKtype, String indexName) throws DBAppException {
		int i = binarySearch(pk, pKtype);
		Tuple t = tuples.get(i);
		BPlusTree tree = BPlusTree.deserialize(indexName);
		tree.insert(t.getPrimaryKey(), t.getColNameValue());

		tree.delete((int)pk );
		for (String columnName : newValue.keySet()) {
			  if (t.ColNameValue.containsKey(columnName)) {
				 if(columnName.equals(t.pkName)) {
					 throw new DBAppException("cannot update the primary key");
				 }
				 else {
					 t.ColNameValue.put(columnName, newValue.get(columnName));
				 }
			  }
			  else {
				  throw new DBAppException("wrong column name");
			  }
			}

		tree.insert(t.getPrimaryKey(), t.getColNameValue());
		BPlusTree.serialize(tree, indexName);
		
		
	}
}

