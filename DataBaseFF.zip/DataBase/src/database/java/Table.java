package database.java;
import java.awt.image.ColorModel;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.invoke.StringConcatFactory;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Table implements Serializable {
   

	private static final long serialVersionUID = 1L;
	
	Hashtable<Integer,String> pages;
	Hashtable<Integer,String> Indexes;
	String TableName;
	int numOfPages;
	int numOfIndexes;
	
	

	public Table(String strTableName) {
		this.TableName = strTableName;
		pages = new Hashtable<>();
		Indexes = new Hashtable<>();
		numOfPages = 0;
		numOfIndexes = 0;
		
	}
	
	public boolean hasIndex() {
		return ! Indexes.isEmpty();
	}
	

	public boolean hasIndexOn(String columnName) throws DBAppException{
			
		
		return Indexes.contains(TableName+"_"+columnName);
	}
	
	public static void serialize(Table table) throws DBAppException {
		try {
//			System.out.println("IO||||\t serialize:table:"+table.getTableName());
			
			FileOutputStream fileOutput = new FileOutputStream("./src/main/resources/data/" + table.TableName + ".ser");
			
			ObjectOutputStream out = new ObjectOutputStream(fileOutput);
			out.writeObject(table);
			out.close();
			fileOutput.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new DBAppException("IO Exception while writing to disk\t Table" + table.TableName);
		}
	}
	
	public static Table deserialize(String tableName) throws DBAppException {
		try {
//			System.out.println("IO||||\t deserialize:table:"+tableName);
			FileInputStream fileInput = new FileInputStream("./src/main/resources/data/"+tableName+".ser");
		
			
			ObjectInputStream in = new ObjectInputStream(fileInput);

			Table table = (Table) in.readObject();
			in.close();
			fileInput.close();

			return table;
		} catch (IOException e) {
			e.printStackTrace();
			throw new DBAppException(
					"IO Exception | Probably wrong table name (tried to operate on a table that does not exist !");
		} catch (ClassNotFoundException e) {
			throw new DBAppException("Class Not Found Exception");
		}
	}
	
	
	
	public String getPrimaryKey() {
		try {
			File metadataFile = new File("./src/main/resources/metadata.csv");
			FileReader fileReader = new FileReader(metadataFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			//String line = bufferedReader.readLine(); //skip first line (header line)
			String line = bufferedReader.readLine();
			while(line != null)
			{
				String[] data = line.split(",");
				if(data[0].equals(this.TableName) && (data[3]).equals("true") ) {
					return data[1];
				}
				line = bufferedReader.readLine();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public Hashtable<String, String> readTable() {
		try {
			File metadataFile = new File("./src/main/resources/metadata.csv");
			FileReader fileReader = new FileReader(metadataFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			//String line = bufferedReader.readLine(); //skip first line 
			Hashtable<String , String> ColNameType = new Hashtable<>();
			String line = bufferedReader.readLine();
			while(line != null)
			{
				String[] data = line.split(",");
				if(data[0].equals(this.TableName)) {
					ColNameType.put(data[1], data[2]);
				}
				line = bufferedReader.readLine();
			}
			
			return ColNameType;
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

	public String getPrimaryKeyType() {
		Hashtable<String, String> ColNameType = readTable();
		String Pkey = getPrimaryKey();
		return ColNameType.get(Pkey);
		
	}
	
	public Hashtable<String, String> getMin(){
		try {
			File metadataFile = new File("./src/main/resources/metadata.csv");
			FileReader fileReader = new FileReader(metadataFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			//String line = bufferedReader.readLine(); //skip first line 
			
			Hashtable<String , String> ColNameMin = new Hashtable<>();
			String line = bufferedReader.readLine();
			while(line != null)
			{
				String[] data = line.split(",");
				if(data[0].equals(this.TableName)) {
					ColNameMin.put(data[1], data[6]);
				}
				line = bufferedReader.readLine();

			}
	
			return ColNameMin;
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	public Hashtable<String, String> getMax(){
		try {
			File metadataFile = new File("./src/main/resources/metadata.csv");
			FileReader fileReader = new FileReader(metadataFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			//String line = bufferedReader.readLine(); //skip first line 
			
			Hashtable<String , String> ColNameMax = new Hashtable<>();
			String line = bufferedReader.readLine();
			while(line != null)
			{
				String[] data = line.split(",");
				
				if(data[0].equals(this.TableName)) {
					ColNameMax.put(data[1], data[7]);
				}
				line = bufferedReader.readLine();
			}
			
			return ColNameMax;
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
//this helper method gets the actual value of a string depending on its data type	
	public static Object parse(String value, String type) { 

		switch (type) {
		case "java.lang.Integer":
		{
			return Integer.parseInt(value);
		}
		case "java.lang.Double":
		{
			return Double.parseDouble(value);
		}
		
		case "java.lang.String":
		{
			return value;
		}
		default:
			return null;
		}
	}

	
	
//this helper method will be used upon insert, update, or delete any tuples it makes sure that the user entered valid data 
	private boolean checkdata(Hashtable<String, Object> htblColNameValue) throws DBAppException {
		Hashtable<String, String> ColNameType = readTable();
		for(String key : htblColNameValue.keySet()) {
			if(!ColNameType.containsKey(key)) {
				throw new DBAppException("wrong column name");
			}
			String inputType = htblColNameValue.get(key).getClass().getName();
			String originalType = ColNameType.get(key);
			
			if(! inputType.equals(originalType)) {
				throw new DBAppException("values do not match types");
			}
		}
			
			
		return true;
	}

	
	public void update(String strClusteringKeyValue, Hashtable<String, Object> newValue) throws DBAppException {
		checkdata(newValue); 
			
		if(strClusteringKeyValue == null) {
			throw new DBAppException("Primary Key field is null");
		}
		String pKtype = getPrimaryKeyType();
		Object pk = parse(strClusteringKeyValue, pKtype);
		if(hasIndex()) {
			String indexName = Indexes.get(0);

			for(Integer key: pages.keySet()) {
				Page page = Page.deserialize(pages.get(key));
				if(inRange(pk,page.minPKey, page.maxPKey)) {
					
					page.updateTupleWithIndex(pk, newValue , pKtype, indexName);
					Page.serialize(page);
					return;
				}
			}
		
			
		}
		for(Integer key: pages.keySet()) {
			Page page = Page.deserialize(pages.get(key));
			if(inRange(pk,page.minPKey, page.maxPKey)) {
				page.updateTuple(pk, newValue , pKtype);
				Page.serialize(page);
				return;
			}
		}
		
		}
	
	
	// following method could be used to delete one or more rows.
	// htblColNameValue holds the key and value. This will be used in search
	// to identify which rows/tuples to delete.
	// htblColNameValue enteries are ANDED together
	//assuming that the input hashtable contains multiple conditions for the tuple(s) to be deleted
	//EXAMPLE: delete age =18 & name = mohamed & name = ahmed
	//if these columns are not the primary keys for the tuples we have to search Linearlyy for the tuple(s) 
	//that satisfy all the conditions andded together
	
	
	public void delete(Hashtable<String, Object> htblColNameValue) throws DBAppException, IOException {
		checkdata(htblColNameValue);
	    boolean flag=false;
	    
	    
	   
	    Iterator<Integer> iter = pages.keySet().iterator();
	    while (iter.hasNext()) {
	        Integer key = iter.next();
	        Page p = Page.deserialize(pages.get(key));
	        String Pkey = getPrimaryKey();
	        if(htblColNameValue.containsKey(Pkey)) {
	        	String pKtype = getPrimaryKeyType();
				Object pk = htblColNameValue.get(Pkey);

				if(inRange(pk,p.minPKey , p.maxPKey)) {
						p.delete1(htblColNameValue, pk, pKtype, Indexes);
						Page.serialize(p);
						return;
				    
					

				}
	        }
			

	      boolean s =p.delete1(htblColNameValue, Indexes);
	     
	      
	       flag=flag||s;
	       
	        if (p.isEmpty()) {
	            FileInputStream fileInput = new FileInputStream("data/" + p.pageName + ".class");
	            fileInput.close();
	            File file = new File("data/" + p.pageName + ".class");
	            file.delete();
	            iter.remove(); // remove the current key from the iterator instead of using pages.remove(key)
	        } else {
	            Page.serialize(p);
	        }
	    }
	    if(!flag)
	    {
	    	throw new DBAppException("Tuples to be deleted does not exist");
	    }
	    
	}
	

	public boolean inRange(Object pk, Object min, Object max) { //just check if pk is >= min or <= max do not do binary search
		String pKtype = getPrimaryKeyType();
		switch (pKtype) {
		case "java.lang.Integer":{
			if (((Integer) pk).compareTo((Integer)min) >= 0 && ((Integer) pk).compareTo((Integer)max) <= 0) {
				
				return true;
			}
			break;
		}
		case "java.lang.Double":{
			if (((Double) pk).compareTo((Double)min) >= 0 && ((Double) pk).compareTo((Double)max) <= 0) {
				return true;
			}
			break;
		}
			
		case "java.util.Date":{
			if (((Date) pk).compareTo((Date)min) >= 0 && ((Date) pk).compareTo((Date)max) <= 0) {
				return true;
			}
			break;
		}
			
		case "java.lang.String":{
			if (((String) pk).compareTo((String)min) >= 0 && ((String) pk).compareTo((String)max) <= 0) {
				return true;
			}
			break;
		}
			
		default:
			break;
		}
		return false;
	}
	
	public void insertInIndex(Tuple tuple, String pageName,String indexName) throws DBAppException {
		BPlusTree tree = BPlusTree.deserialize(indexName);

		tree.insert(tuple.getPrimaryKey(), tuple.getColNameValue());


		BPlusTree.serialize(tree, indexName);
	}
	
	public boolean insert(Hashtable<String, Object> htblColNameValue) throws DBAppException {
		checkdata(htblColNameValue);
		
		String Pkey = getPrimaryKey();
		String pKtype = getPrimaryKeyType();
		Object pk = htblColNameValue.get(Pkey);
		if(pk==null) {
			throw new DBAppException("primary key doesn't exist");
		}
		Tuple newTuple = new Tuple(htblColNameValue, Pkey ,pk ,pKtype);
		
		//case 0: empty table
		if(pages.isEmpty()) { //create a new page
			String frstPageName = TableName + "_"+ numOfPages;
			Page frstPage = new Page(frstPageName,pk, pk);
			pages.put(numOfPages, frstPageName);
			numOfPages++;
			frstPage.insert(newTuple , 0);
			Page.serialize(frstPage);
			
			if(hasIndex()) {
				for(Integer key: Indexes.keySet()) {
					String indexName = Indexes.get(key);
					insertInIndex(newTuple, frstPageName, indexName);
					
				}
			}
			return true;
		}
		
		//find the correct page
		int size = pages.size();
		int pIndex = 0;
		int i = 0;
		while (i < size) {
		    String pageName = pages.get(i);
		    Page page = Page.deserialize(pageName);
		    if (inRange(pk, page.minPKey, page.maxPKey)) {
		        pIndex = i;
		        Page.serialize(page);
		        break;
		    }
		    
		    String nxtPageName = pages.get(i + 1);
		    if (nxtPageName != null) {
		        Page nxtPage = Page.deserialize(nxtPageName);
		        if (inRange(pk, page.maxPKey, nxtPage.minPKey) && (!page.isFull())) {
		            page.insert(newTuple, page.size());
		            Page.serialize(nxtPage);
		            Page.serialize(page);
		            if (hasIndex()) {
		                for (Integer key : Indexes.keySet()) {
		                    String indexName = Indexes.get(key);
		                    insertInIndex(newTuple, pageName, indexName);
		                }
		            }
		            return true;
		        }
		    }
		    
		    if ((!page.isFull()) && (nxtPageName == null)) {
		        pIndex = i;
		        Page.serialize(page);
		        break;
		    }
		    
		    if (pIndex == 0 && (((Comparable) pk).compareTo((Comparable) page.minPKey) < 0)) {
		        pIndex = i;
		        Page.serialize(page);
		        break;
		    }
		    
		    if (nxtPageName == null) {  
		        String newPageName = TableName + "_" + numOfPages;
		        Page newPage = new Page(newPageName, pk, pk);
		        pages.put(numOfPages, newPageName);
		        numOfPages++;
		        newPage.insert(newTuple , 0);
		        Page.serialize(newPage);
		        Page.serialize(page);
		        
		        if (hasIndex()) {
		            for (Integer key : Indexes.keySet()) {
		                String indexName = Indexes.get(key);
		                insertInIndex(newTuple, newPageName, indexName);
		            }
		        }
		        
		        return true;
		    }
		    
		    Page.serialize(page);
		    i++;
		}

		
		String correctPageName = pages.get(pIndex);
		Page correctPage = Page.deserialize(correctPageName); 
		int tupleIndex = correctPage.binarySearch(pk, pKtype);
		
		
		
		//case 1: page is not full
		if(!correctPage.isFull()) {
			//case 1-1: tuple place is empty 
			if(correctPage.getTuple(tupleIndex) == null) {
				correctPage.insert(newTuple, tupleIndex);
				Page.serialize(correctPage);
				if(hasIndex()) {
					for(Integer key: Indexes.keySet()) {
					String indexName = Indexes.get(key);
					insertInIndex(newTuple, correctPageName, indexName);
					}
				}
				return true;
			}
			//case 1-2: tuple place is not empty(must shift)
			if(correctPage.getTuple(tupleIndex) != null) {
				//if pk already exists
				if(correctPage.getTuple(tupleIndex).Pkey.equals(pk)) {
					throw new DBAppException("primary key already exists");
				}
				correctPage.shift(tupleIndex);
				correctPage.insert(newTuple, tupleIndex);
				Page.serialize(correctPage);
				if(hasIndex()) {
					for(Integer key: Indexes.keySet()) {
						String indexName = Indexes.get(key);
						insertInIndex(newTuple, correctPageName, indexName);
					}
				}
				return true;
			}
		}
		
		//case 2: page is full
		if(correctPage.isFull()) {
			//case 2-1: tuple place is empty 
			if(correctPage.getTuple(tupleIndex) == null) {
				correctPage.insert(newTuple, tupleIndex);
				Page.serialize(correctPage);
				if(hasIndex()) {
					for(Integer key: Indexes.keySet()) {
						String indexName = Indexes.get(key);
						insertInIndex(newTuple, correctPageName, indexName);
					}
				}
				return true;
			}
			//case 2-2: tuple place is not empty(must shift)
			if(correctPage.getTuple(tupleIndex) != null) {
				//if pk already exists
				if(correctPage.getTuple(tupleIndex).Pkey.equals(pk)) {
					throw new DBAppException("primary key already exists");
				}
				Tuple lastTuple = correctPage.getTuple(correctPage.size()-1);
				correctPage.shift(tupleIndex);
				correctPage.insert(newTuple, tupleIndex);
				Page.serialize(correctPage);
				if(hasIndex()) {
					for(Integer key: Indexes.keySet()) {
						String indexName = Indexes.get(key);
				
						insertInIndex(lastTuple, correctPageName, indexName);
					}
				}
				
				//insert the last tuple (resulting from shifting) in the correct page
				int counter = pIndex + 1;
				while (counter <= size) {
				    String nxtPageName = pages.get(counter);
				    
				    // Case 2-2-1: No next page
				    if (nxtPageName == null) {
				        String pageName = TableName + "_" + numOfPages;
				        Page page = new Page(pageName, lastTuple.Pkey, lastTuple.Pkey);
				        pages.put(numOfPages, pageName);
				        numOfPages++;
				        page.insert(lastTuple, 0);
				        Page.serialize(page);
				        if (hasIndex()) {
				            for (Integer key : Indexes.keySet()) {
				                String indexName = Indexes.get(key);
				                insertInIndex(lastTuple, pageName, indexName);
				            }
				        }
				        return true;
				    }
				    
				    Page nxtPage = Page.deserialize(nxtPageName);
				    
				    // Case 2-2-2: Next page is not full
				    if (!nxtPage.isFull()) {
				        nxtPage.shift(0);
				        nxtPage.insert(lastTuple, 0);
				        Page.serialize(nxtPage);
				        if (hasIndex()) {
				            for (Integer key : Indexes.keySet()) {
				                String indexName = Indexes.get(key);
				                insertInIndex(lastTuple, nxtPageName, indexName);
				            }
				        }
				        return true;
				    }
				    
				    // Case 2-2-3: Next page is full
				    if (nxtPage.isFull()) {
				        newTuple = lastTuple;
				        lastTuple = nxtPage.getTuple(nxtPage.size() - 1);
				        nxtPage.shift(0);
				        nxtPage.insert(newTuple, 0);
				        Page.serialize(nxtPage);
				        if (hasIndex()) {
				            for (Integer key : Indexes.keySet()) {
				                String indexName = Indexes.get(key);
				                insertInIndex(lastTuple, nxtPageName, indexName);
				            }
				        }
				    }
				    
				    i++;
				}
				

			}
		}
		return false;
	}
	 public void display() throws DBAppException {
		 for(Integer key: pages.keySet()) {
				Page p = Page.deserialize(pages.get(key));
				System.out.println("page "+key +":" + p.toString());
				Page.serialize(p);
				}
				
	 }
	 
	 public ArrayList<Tuple> selectFromTable(SQLTerm s) throws DBAppException {
		 String colName = s._str_Column_Name;
		 String operator = s._str_Operator;
		 Object value = s._obj_Value;
		 ArrayList<Tuple> result = new ArrayList<>();
		
		 switch(operator) {
		 case "=":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInsideTuple = t.ColNameValue.get(colName);
					 if(valueInsideTuple.equals(value)) {
						 result.add(t);
					 }
					 
				 }
				 Page.serialize(page);
			 }
			 
			 break;
		 case "!=":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInsideTuple = t.ColNameValue.get(colName);
					 if(!valueInsideTuple.equals(value)) {
						 result.add(t);
					 }
					 
				 }
				 Page.serialize(page);
			 }
			 break;
		 case ">":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInsideTuple = t.ColNameValue.get(colName);
					 String type = valueInsideTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInsideTuple).compareTo((Integer)value)>0) {
							 result.add(t);
							
						 }
						 break;
					 case"java.lang.Double":
						 if(((Double)valueInsideTuple).compareTo((Double)value)>0) {
							 result.add(t);
							
						 }
						 break;
					 case "java.lang.String":
						 if(((String)valueInsideTuple).compareTo((String)value)>0) {
							 result.add(t);
							 
						 } break;
					 case "java.lang.Date":
						 if(((Date)valueInsideTuple).compareTo((Date)value)>0) {
							 result.add(t);
						
						 } break;
						default: break; 
					 } 
				 }
				 Page.serialize(page);
			 }
			 
			 break;
		 case "<":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInsideTuple = t.ColNameValue.get(colName);
					 String type = valueInsideTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInsideTuple).compareTo((Integer)value)<0) {
							 result.add(t);
							 
						 } break;
						 
					 case"java.lang.Double":
						 if(((Double)valueInsideTuple).compareTo((Double)value)<0) {
							 result.add(t);
							
						 } break;
						 
					 case "java.lang.String":
						 if(((String)valueInsideTuple).compareTo((String)value)<0) {
							 result.add(t);
							
						 } break;
					 case "java.lang.Date":
						 if(((Date)valueInsideTuple).compareTo((Date)value)<0) {
							 result.add(t);
							
						 }  break;
					 default: break;
					 } 
				 }
				 Page.serialize(page);
			 }
			 break;
		 case ">=":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInsideTuple = t.ColNameValue.get(colName);
					 String type = valueInsideTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInsideTuple).compareTo((Integer)value)>=0) {
							 result.add(t);
							 
						 } break;
						 
					 case"java.lang.Double":
						 if(((Double)valueInsideTuple).compareTo((Double)value)>=0) {
							 result.add(t);
							 
						 } break;
						 
					 case "java.lang.String":
						 if(((String)valueInsideTuple).compareTo((String)value)>=0) {
							 result.add(t);
							
						 } break;
					 case "java.lang.Date":
						 if(((Date)valueInsideTuple).compareTo((Date)value)>=0) {
							 result.add(t);
							 
						 } break;
					default: break;	 
					 } 
				 }
				 Page.serialize(page);
			 }
			 break;
		 case "<=":
			 for(Integer key: pages.keySet()) {
				 Page page = Page.deserialize(pages.get(key));
				 for(Tuple t : page.tuples) {
					 //checks
					 Object valueInsideTuple = t.ColNameValue.get(colName);
					 String type = valueInsideTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInsideTuple).compareTo((Integer)value)<=0) {
							 result.add(t);
							 
						 }
						 break;
					 case"java.lang.Double":
						 if(((Double)valueInsideTuple).compareTo((Double)value)<=0) {
							 result.add(t);
							
						 } break;
						 
					 case "java.lang.String":
						 if(((String)valueInsideTuple).compareTo((String)value)<=0) {
							 result.add(t);
							
						 } break;
					 case "java.lang.Date":
						 if(((Date)valueInsideTuple).compareTo((Date)value)<=0) {
							 result.add(t);
							
						 } break;
					default: break;	 
					 } 
				 }
				 Page.serialize(page);
			 }
			 break;
		 default: break;
		 
	 }
		 return result;
		
		
	 }
	 
	 
	 public void displayIndex(String indexName) throws DBAppException {
		BPlusTree index = BPlusTree.deserialize(indexName);
		index.display();
		BPlusTree.serialize(index, indexName);
	 }
	

	public void createIndex(String strarrColName) throws DBAppException {
		Hashtable<String, String> ColNameType = readTable(); 
		String indexName = TableName+"_"+ strarrColName;


        if(Indexes.containsValue(indexName)) {
        	throw new DBAppException("Column already indexed");
        }
		
		BPlusTree tree = new BPlusTree(this.TableName, strarrColName+" "+ "Index", 4);
		

		if(!pages.isEmpty()) {
			for(Integer key: pages.keySet()) {
				Page page = Page.deserialize(pages.get(key));
				
				for(Tuple t: page.tuples) {

					tree.insert(t.getPrimaryKey(), t.getColNameValue());
				}
				
				
				Page.serialize(page);
				}
		}
		Indexes.put(numOfIndexes, indexName );
		numOfIndexes++;

		BPlusTree.serialize(tree, indexName);
	
		
		
	}
	

	public ArrayList<Tuple> selectFromIndex(String indexName, SQLTerm arrSQLTerms) throws DBAppException {
			
			//ArrayList<Tuple> result = new ArrayList<>();
			Hashtable<String, Object> result  = new Hashtable<String, Object>();
        	ArrayList<Hashtable<String, Object>> results = new ArrayList<>();
        	String columnName = arrSQLTerms._str_Column_Name;

			
			String operator = arrSQLTerms._str_Operator;
			
			Object value = arrSQLTerms._obj_Value;
			BPlusTree index = BPlusTree.deserialize(indexName);

			 switch(operator) {
			 case "=":
					result  = index.search((int) value);
					results.add(result);
				 
				 break;
			 case "!=":  
				 for(Integer key: pages.keySet()) {
					 Page page = Page.deserialize(pages.get(key));
					 for(Tuple t : page.tuples) {
						 //checks
						 Object valueInsideTuple = t.ColNameValue.get(columnName);
						 if(!valueInsideTuple.equals(value)) {
							 result = t.ColNameValue;
							 results.add(result);
						 }
						 
					 }
					 Page.serialize(page);
				 }
				 break;
			 case ">":
				 results=index.search(((int)value)+1, Integer.MAX_VALUE);
				 
				 break;
			 case "<":
				 results=index.search(Integer.MIN_VALUE, ((int)value)-1);


				 break;
			 case ">=":
				 results=index.search(((int)value), Integer.MAX_VALUE);

				 break;
			 case "<=":
				 results=index.search(Integer.MIN_VALUE, ((int)value));

				 break;
			 default: break;
			 
		 }

			BPlusTree.serialize(index, indexName);
			ArrayList<Tuple> resultTuples = new ArrayList<Tuple>();
			for(Hashtable<String, Object> item : results) {
				Tuple t = new Tuple(item, "", "", "");
				resultTuples.add(t);
				
			}
			return resultTuples;
	}	
	}

