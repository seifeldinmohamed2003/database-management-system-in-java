package database.java;
import java.io.Serializable;
import java.util.Hashtable;

public class Tuple implements Serializable{
	
	Hashtable<String, Object> ColNameValue;
	Object Pkey;
	String pkName;
	String pkType;
	
	public Tuple(Hashtable<String, Object> ColNameValue, String pkName, Object pk, String pkType) {
		this.ColNameValue = ColNameValue;
		this.Pkey = pk;
		this.pkName = pkName;
		this.pkType = pkType;
	}
	
	public String toString()
	{
	 return	ColNameValue.toString() + '\n';		
	}
	
	public boolean equals(Tuple t) {
		return this.Pkey.equals(t.Pkey);
	}
	
	public Hashtable<String, Object> getColNameValue() {
		return ColNameValue;
	}
	
	public void setColNameValue(Hashtable<String, Object> colNameValue) {
		ColNameValue = colNameValue;
	}

	public void setPrimaryKey(Object primaryKey) {
		this.Pkey = primaryKey;
	}
	
	public String getPkName() {
		return pkName;
	}
	public void setPkName(String pkName) {
		this.pkName = pkName;
	}
	public String getPkType() {
		return pkType;
	}
	public void setPkType(String pkType) {
		this.pkType = pkType;
	}
	public int getPrimaryKey() {
		// TODO Auto-generated method stub
		return (int)Pkey;
	}
}
