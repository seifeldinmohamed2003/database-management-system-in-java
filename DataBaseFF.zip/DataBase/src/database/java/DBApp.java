package database.java;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;







public class DBApp {
	
	public DBApp() {
	}

	public void init() {
		try {
			File Tdirectory = new File("./src/main/resources/data");
			Tdirectory.mkdir();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}
	

	public ArrayList<Tuple> selectFromResult(SQLTerm s, ArrayList<Tuple> resultList) throws DBAppException {
		 String columnName = s._str_Column_Name;
		 String operator = s._str_Operator;
		 Object value = s._obj_Value;
		 ArrayList<Tuple> result = new ArrayList<>();
		
		 switch(operator) {
		 case "=":
				 for(Tuple t : resultList) {
					 //checks
					 Object valueInsideTuple = t.ColNameValue.get(columnName);
					 if(valueInsideTuple.equals(value)) {
						 result.add(t);
					 } 
				 }
			 			 
			 break;
		 case "!=":
				 for(Tuple t : resultList) {
					 //checks
					 Object valueInsideTuple = t.ColNameValue.get(columnName);
					 if(!valueInsideTuple.equals(value)) {
						 result.add(t);
					 }
			 }
			 break;
		 case ">":
				 for(Tuple t : resultList) {
					 //checks
					 Object valueInsideTuple = t.ColNameValue.get(columnName);
					 String type = valueInsideTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInsideTuple).compareTo((Integer)value)>0) {
							 result.add(t);
							
						 } break;
						 
					 case"java.lang.Double":
						 if(((Double)valueInsideTuple).compareTo((Double)value)>0) {
							 result.add(t);
							
						 }
						 break;
					 case "java.lang.String":
						 if(((String)valueInsideTuple).compareTo((String)value)>0) {
							 result.add(t);
							 
						 } break;
					
						default: break; 
					 } 
					
				 }
			 
			 break;
		 case "<":
				 for(Tuple t : resultList) {
					 //checks
					 Object valueInTuple = t.ColNameValue.get(columnName);
					 String type = valueInTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInTuple).compareTo((Integer)value)<0) {
							 result.add(t);
						 }
						 break;
						 
					 case"java.lang.Double":
						 if(((Double)valueInTuple).compareTo((Double)value)<0) {
							 result.add(t);
							 
						 } break;
						 
					 case "java.lang.String":
						 if(((String)valueInTuple).compareTo((String)value)<0) {
							 result.add(t);
							
						 }  break;
					
						 default: break;
					 } 
			 }
			 break;
		 case ">=":
				 for(Tuple t : resultList) {
					 //checks
					 Object valueInTuple = t.ColNameValue.get(columnName);
					 String type = valueInTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInTuple).compareTo((Integer)value)>=0) {
							 result.add(t);
							 
						 }  break;
						 
					 case"java.lang.Double":
						 if(((Double)valueInTuple).compareTo((Double)value)>=0) {
							 result.add(t);
							 
						 }  break;
						 
					 case "java.lang.String":
						 if(((String)valueInTuple).compareTo((String)value)>=0) {
							 result.add(t);
							
						 }  break;
					
						 default: break;
					 } 
			 }
			 break;
		 case "<=":
				 for(Tuple t : resultList) {
					 //checks
					 Object valueInTuple = t.ColNameValue.get(columnName);
					 String type = valueInTuple.getClass().getName();
					 switch(type) {
					 case "java.lang.Integer":
						 if(((Integer)valueInTuple).compareTo((Integer)value)<=0) {
							 result.add(t);
							 
						 }  break;
						 
					 case"java.lang.Double":
						 if(((Double)valueInTuple).compareTo((Double)value)<=0) {
							 result.add(t);
							 
						 }
						 break;
					 case "java.lang.String":
						 if(((String)valueInTuple).compareTo((String)value)<=0) {
							 result.add(t);
							
						 }  break;
					
						 default: break;
					 } 
			 }
			 break;
		 default: break;
		 
	 }
		 return result;
		
		
	 }
	public Iterator<Tuple> selectFromTable(SQLTerm[] arrSQLTerms, String[] strarrOperators) throws DBAppException {
		ArrayList<Tuple> r1 = new ArrayList<>();
		ArrayList<Tuple> r2 = new ArrayList<>();
		String indexName;
		SQLTerm s1 = arrSQLTerms[0];
		Table table = Table.deserialize(s1._str_Table_Name);
		if (!tableDoesExist(s1._str_Table_Name)) {
            throw new DBAppException("Table " + s1._str_Table_Name + " does not exist");
        }
		boolean hasIndex = false;
		int executedQuery = 0;
		
		for (int i=0 ; i<arrSQLTerms.length;i++) {
			SQLTerm s = arrSQLTerms[i];
			String columnName=s._str_Column_Name;
			
			if(table.hasIndexOn(s._str_Column_Name)){
				hasIndex=true;
				indexName = table.TableName+"_"+ s._str_Column_Name;
				r1=table.selectFromIndex(indexName,arrSQLTerms[i]);
				executedQuery=i;
				break;
				
				
			}
					
		}
		if(!hasIndex)
			r1 =table.selectFromTable(s1);

		
		int j = 0;

		for (int i =0; i< arrSQLTerms.length;i++) {
			
			if(i==executedQuery)
				continue;
			
			SQLTerm s = arrSQLTerms[i];
			String columnName=s._str_Column_Name;
			String o = strarrOperators[j];
			j++;
			switch(o) {
			
			case "AND":
					r1 = selectFromResult(s, r1);
				break;	
				
			case "OR":
				r2 =table.selectFromTable(s);
				for(Tuple tuple : r2) {
					if(r1.contains(tuple)) 
						continue;
					else
						r1.add(tuple);
				}
				
				break;
				
			case "XOR":
				
				r2 =table.selectFromTable(s);
				r1 = xOR(r1, r2);
				break;
				
			default: break;	
			
			}
			

		}
		

		Table.serialize(table);
		return r1.iterator();
	
	}
	
	private ArrayList<Tuple> xOR(ArrayList<Tuple> r1, ArrayList<Tuple> r2) {
		ArrayList<Tuple> result = new ArrayList<>();
		
		for(Tuple tu1: r1) {
			boolean flag1 = false;
			for(Tuple tu2: r2) {
				flag1 = flag1 || tu1.equals(tu2);
				
			}
			if(!flag1) {
				result.add(tu1);
			}
		}
		
		for(Tuple tu2: r2) {
			boolean flag2 = false;
			for(Tuple tu1: r1) {
				flag2 = flag2 || tu1.equals(tu2);
			}
			if(!flag2) {
				result.add(tu2);
			}
		}
		return result;
	}

	public void createTable(String strTableName, String strClusteringKeyColumn,
            Hashtable<String,String> htblColNameType ) throws DBAppException {
    // Check if the table already exists
	if (tableDoesExist(strTableName)) {
	    throw new DBAppException("Table " + strTableName + " already does exists.");
	}

	// Create a new table directory
	File Tdirectory = new File(strTableName);
	if (!Tdirectory.mkdir()) {
	    throw new DBAppException("Can't create a table directory for " + strTableName);
    
      
	   
	}
	writeMetadataFile(strTableName, strClusteringKeyColumn, htblColNameType);

    
}
	

	private static void writeMetadataFile(String strTableName, String strClusteringKeyColumn,
            Hashtable<String,String> htblColNameType) throws DBAppException {
		// Write the table metadata to a metadata file
        String Fpath = "./src/main/resources/metadata.csv";
        try {
	

        File metadataFile = new File(Fpath);

        // If metadata file doesn't exist, write the header row
        if (!metadataFile.exists()) {
            FileWriter fileWriter = new FileWriter(metadataFile);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write("TableName,ColumnName,ColumnType,IsClusteringKey,IndexName,IndexType\n");
            bufferedWriter.flush();
            bufferedWriter.close();
        }

        // Write the column metadata
        FileWriter fileWriter = new FileWriter(metadataFile, true); // append to existing file
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

        Enumeration<String> columnNames = htblColNameType.keys();
        while (columnNames.hasMoreElements()) {
            String columnName = columnNames.nextElement();
            String columnType = htblColNameType.get(columnName);
            
            String isClusteringKey = columnName.equals(strClusteringKeyColumn) ? "true" : "false";
            boolean hasIndex = false;
            
            bufferedWriter.write(strTableName + "," + columnName + "," + columnType + "," + isClusteringKey + "," + "null" + "," + "null" + ","   + ","  + "\n");
        }

        bufferedWriter.flush();
        bufferedWriter.close();
		}
		catch (IOException e) {
			e.printStackTrace();
}
        Table table = new Table(strTableName);
        Table.serialize(table);
        
       
    } 
	
		
	public static void updateIndexMetadataFile(String strTableName,String indexedColumn,String indexName) throws DBAppException {
		try {
	        String Fpath = "./src/main/resources/metadata.csv";
	        File metadataFile = new File(Fpath);

	        if (!metadataFile.exists()) {
	            throw new DBAppException("Metadata file does not exist.");
	        }

	        // Read the existing metadata file
	        List<String> lines = Files.readAllLines(metadataFile.toPath());
	        List<String> updatedLines = new ArrayList<>();

	        // Update the specific line for the indexed column
	        for (String line : lines) {
	            String[] parts = line.split(",");
	            if (parts.length >= 5 && parts[0].equals(strTableName) && parts[1].equals(indexedColumn)) {
	                // Replace index name and index type
	                parts[4] = indexName;
	                parts[5] = "B+ Tree";
	                line = String.join(",", parts);
	            }
	            updatedLines.add(line);
	        }

	        // Write the updated metadata back to the file
	        Files.write(metadataFile.toPath(), updatedLines);

	    } catch (IOException e) {
	        throw new DBAppException("Editing index metadata failed!: " + e.getMessage());
	    }
		
	}
	private static boolean tableDoesExist(String strTableName) {
	    File Tdirectory = new File("./src/main/resources/data/"+strTableName+".ser");
	    return Tdirectory.exists() ;
	}
	
	
	public void insertIntoTable(String strTableName, Hashtable<String, Object> htblColNameValue) throws DBAppException {
		
			if (!tableDoesExist(strTableName)) {
	            throw new DBAppException("Table " + strTableName + " does not exist");
	        }
				Table tb = Table.deserialize(strTableName);
				System.out.println(tb.insert(htblColNameValue));
				Table.serialize(tb);
			}
	public void updateTable(String strTableName, String strClusteringKeyValue,
			Hashtable<String, Object> htblColNameValue) throws DBAppException {
		if (!tableDoesExist(strTableName)) {
           throw new DBAppException("Table " + strTableName + " does not exist");
    }
			Table table = Table.deserialize(strTableName);
				table.update(strClusteringKeyValue, htblColNameValue);
				Table.serialize(table);
				return;
			}
	

	// following method could be used to delete one or more rows.
	// htblColNameValue holds the key and value. This will be used in search
	// to identify which rows/tuples to delete.
	// htblColNameValue enteries are ANDED together
	public void deleteFromTable(String strTableName, Hashtable<String, Object> htblColNameValue) throws DBAppException, IOException {
		if (!tableDoesExist(strTableName)) {
	           throw new DBAppException("Table " + strTableName + " does not exist");}
				Table table = Table.deserialize(strTableName);
				table.delete(htblColNameValue);
				Table.serialize(table);
				return;
			}
			
		public static void displayTable(String tableName) throws DBAppException {
			Table t = Table.deserialize(tableName);
			t.display();
			Table.serialize(t);
		}
		
		public static void createIndex(String strTableName, String strarrColName) throws DBAppException
		{
			if(!tableDoesExist(strTableName))
			{
				throw new DBAppException("table doesn't exist");
			}
			
			
			Table table = Table.deserialize(strTableName);
			table.createIndex(strarrColName);
			updateIndexMetadataFile(strTableName, strarrColName, strarrColName+"Index");
			Table.serialize(table);
			
		}
		  
		public void displayIndex(String strTableName, String indexName) throws DBAppException {
			Table table = Table.deserialize(strTableName);
			table.displayIndex(indexName);
			Table.serialize(table);
			
		}

	
//----------------------------------------------------------------------------------------------------------------------------------------------------
	
	public static void main(String[] args) throws Exception {
		
		
		
		String strTableName = "Student2";
		
		DBApp dbApp = new DBApp( ); 
		dbApp.init();
		System.out.println();
		Hashtable <String,String> htblColNameType = new Hashtable <>( ); 
		htblColNameType.put("id", "java.lang.Integer"); 
		htblColNameType.put("age", "java.lang.Integer"); 
		htblColNameType.put("name", "java.lang.String"); 
		htblColNameType.put("major", "java.lang.String"); 
		htblColNameType.put("gpa", "java.lang.Double"); 
		htblColNameType.put("phone", "java.lang.String"); 
		htblColNameType.put("email", "java.lang.String"); 
		htblColNameType.put("address", "java.lang.String"); 
//		
////
//		try {
//		dbApp.createTable( strTableName, "id", htblColNameType);
//	} catch (DBAppException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
		Hashtable<String,Object> htblColNameValue = new Hashtable<>( ); 
//		
		htblColNameValue.put("id", 1);

		htblColNameValue.put("name", "Aml");
		htblColNameValue.put("major", "MET2");
		htblColNameValue.put("age", 20);
		htblColNameValue.put("gpa", 0.7);
		htblColNameValue.put("phone", "111");
		htblColNameValue.put("email", "aaa");
		htblColNameValue.put("address", "aaa");
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
//
//		dbApp.updateTable(strTableName,"1", htblColNameValue);
////
//////
////		
//
//		
//////		displayTable(strTableName);
//////		
		htblColNameValue.clear();
//		
		htblColNameValue.put("id", 2);
		htblColNameValue.put("age", 19);
		htblColNameValue.put("name", "Rowayda");
		htblColNameValue.put("major", "IET");
		htblColNameValue.put("gpa", 0.8);
		htblColNameValue.put("phone", "222");
		htblColNameValue.put("email", "bbb");
		htblColNameValue.put("address", "bbb");
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
////
//////		
//////		
////		htblColNameValue.clear();
////		
		htblColNameValue.put("id", 3);
		htblColNameValue.put("age", 30);
		htblColNameValue.put("name", "Rotana");
		htblColNameValue.put("major", "IET");
		htblColNameValue.put("gpa", 0.8);
		htblColNameValue.put("phone", "333");
		htblColNameValue.put("email", "ccc");
		htblColNameValue.put("address", "ccc");
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
////		
//////		
		htblColNameValue.clear();
		htblColNameValue.put("id", 4);
		htblColNameValue.put("age", 25);
		htblColNameValue.put("name", "Farah");
		htblColNameValue.put("major", "DMET");
		htblColNameValue.put("gpa",  0.7);
		htblColNameValue.put("phone", "444");
		htblColNameValue.put("email", "ddd");
		htblColNameValue.put("address", "ddd");
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
//////		
		htblColNameValue.clear();
		htblColNameValue.put("id", 10);
		htblColNameValue.put("age", 35);
		htblColNameValue.put("name", "Rana");
		htblColNameValue.put("major", "DMET");
		htblColNameValue.put("gpa",  1.0);
		htblColNameValue.put("phone", "555");
		htblColNameValue.put("email", "dde");
		htblColNameValue.put("address", "dedd");
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
////		
		htblColNameValue.clear();
		htblColNameValue.put("id", 8);
		htblColNameValue.put("age", 45);
		htblColNameValue.put("name", "Ahmed");
		htblColNameValue.put("major", "Law");
		htblColNameValue.put("gpa",  4.0);
		htblColNameValue.put("phone", "666");
		htblColNameValue.put("email", "ddez");
		htblColNameValue.put("address", "dezdd");
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
//		dbApp.createIndex(strTableName, "id");
		
//		updateIndexMetadataFile(strTableName, "id", "idIndex");
//		displayTable(strTableName);
		Table table = Table.deserialize(strTableName);
//	System.out.println(table.Indexes.get(0));
		String indexName= table.Indexes.get(0);
//		dbApp.deleteFromTable(strTableName, htblColNameValue);
//		displayTable(strTableName);

//	
//		dbApp.updateTable(strTableName,"1", htblColNameValue);
		BPlusTree tree = BPlusTree.deserialize(indexName);
		//System.out.println(table.hasIndexOn()); ;
		System.out.println(indexName);


//		
//		
//		
////		SQLTerm[] sqlterms = new SQLTerm[1];
////		
////		sqlterms[0] = new SQLTerm(strTableName, "name", "=", "Farah");
////		
////		Iterator<Tuple> iterator= dbApp.selectFromTable(sqlterms, null);
////		
//		String[] columns = new String[3];
//		columns[0] = "age";
//		columns[1] = "name"; 
//		columns[2] = "gpa";
//		
//		createIndex(strTableName, columns);
//		
//		String IndexName1 = strTableName +"_"+ columns[0] + "_" + columns[1] + "_" + columns[2] ;
//		
//		
//		columns = new String[3];
//		columns[0] = "phone";
//		columns[1] = "email"; 
//		columns[2] = "address";
//		
//		createIndex(strTableName, columns);
//		
//		String IndexName2 = strTableName +"_"+ columns[0] + "_" + columns[1] + "_" + columns[2] ;
//		
//		
//		//inserting tuple after creating an indexes.. it should be inserted in both
//		htblColNameValue.clear();
//		htblColNameValue.put("id", 7);
//		htblColNameValue.put("age", 55);
//		htblColNameValue.put("name", "Mohamed");
//		htblColNameValue.put("major", "Law");
//		htblColNameValue.put("gpa",  2.0);
//		htblColNameValue.put("phone", "777");
//		htblColNameValue.put("email", "mmm");
//		htblColNameValue.put("address", "mmm");
////		htblColNameValue.put("date of birth", new Date( "45/4/4"));
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
//
//		
//		htblColNameValue.clear();
//		htblColNameValue.put("id", 8);
//		htblColNameValue.put("age", 66);
//		htblColNameValue.put("name", "Mohamed");
//		htblColNameValue.put("major", "Law");
//		htblColNameValue.put("gpa",  4.0);
//		htblColNameValue.put("phone", "788");
//		htblColNameValue.put("email", "mmmm");
//		htblColNameValue.put("address", "mmim");
////		htblColNameValue.put("date of birth", new Date( "45/4/4"));
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
//		
//		
//		//duplicate
//		htblColNameValue.clear();
//		htblColNameValue.put("id", 20);
//		htblColNameValue.put("age", 66);
//		htblColNameValue.put("name", "Mohamed");
//		htblColNameValue.put("major", "Law");
//		htblColNameValue.put("gpa",  4.0);
//		htblColNameValue.put("phone", "788");
//		htblColNameValue.put("email", "mmmm");
//		htblColNameValue.put("address", "mmim");
////		htblColNameValue.put("date of birth", new Date( "45/4/4"));
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
//		
//		
////		htblColNameValue.clear();
////		htblColNameValue.put("id", 20);
////		dbApp.deleteFromTable(strTableName, htblColNameValue);
////		
		table.display();
		SQLTerm[] arraySqlTerms= new SQLTerm[3];
		arraySqlTerms[0] = new SQLTerm(strTableName, "name", ">", "Aml");
		arraySqlTerms[1] = new SQLTerm(strTableName, "id", "<", 3);
		arraySqlTerms[2] = new SQLTerm(strTableName, "gpa", ">", 1.0);
		
		String[] operators = {"AND" ,"OR"};
//		System.out.println(table.selectFromIndex(indexName, new SQLTerm(strTableName, "id", ">", 3)));
		
		
		Iterator<Tuple> iter = dbApp.selectFromTable(arraySqlTerms, operators);
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
////		
////		displayTable(strTableName);
//		dbApp.displayIndex(strTableName, IndexName1);
//		dbApp.displayIndex(strTableName, IndexName2);
		
		
		
//		htblColNameValue.clear();
//		htblColNameValue.put("id", 5);
//		htblColNameValue.put("age", 15);
//		htblColNameValue.put("name", "Rana");
//		htblColNameValue.put("major", "DMET");
//		htblColNameValue.put("gpa",  0.7);
//		dbApp.insertIntoTable(strTableName,htblColNameValue);
//	
//		displayTable(strTableName);
//		dbApp.displayIndex(strTableName, IndexName);
//		
//		htblColNameValue.clear();
//		
//		htblColNameValue.put("age", 12);
//		htblColNameValue.put("name", "Aml");
//		
//		
////		htblColNameValue.put("id", 5);
//		dbApp.deleteFromTable(strTableName, htblColNameValue);
//		
////		htblColNameValue.clear();
////		htblColNameValue.put("age", 30);
////
////		dbApp.updateTable(strTableName,"5" , htblColNameValue);
//		displayTable(strTableName);
//		dbApp.displayIndex(strTableName, IndexName);
		
	

		
		
		
		
		
		


				
			
	}
}
