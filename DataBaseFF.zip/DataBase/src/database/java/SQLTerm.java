package database.java;

public class SQLTerm {
	String _str_Table_Name;
	String _str_Column_Name;
	String _str_Operator;
	Object _obj_Value;
	
	
	public SQLTerm(String tName, String cName, String op, Object objValue) {
		this._str_Table_Name = tName;
		this._str_Column_Name = cName;
		this._str_Operator = op;
		this._obj_Value = objValue;
	}
	
}
